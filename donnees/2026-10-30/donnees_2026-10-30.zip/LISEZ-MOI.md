# Offre de soins et santé mentale en France par territoire, données agrégées

Version du 30 octobre 2026. Auteur, Lucas Pithon (ORCID 0000-0003-2400-368X). Contact, contact@ubicura.fr.

Effectifs de professionnels de santé et indicateurs de contexte agrégés par territoire (France, régions, départements, intercommunalités, communes), avec les analyses publiées dans les rapports. Aucun nom ni identifiant de professionnel. Le fichier dictionnaire_des_colonnes.md décrit chaque fichier et chaque colonne. Les fichiers CSV sont séparés par des points-virgules, avec la virgule comme séparateur décimal.

## Licences

Résultats sous Licence Ouverte 2.0, en citant la source et la date de la version, sauf les indicateurs tirés des bases de l'Assurance Maladie (Cnam, data.ameli.fr, cartographie des pathologies, secteurs conventionnels, patients sans médecin traitant) et ce qui en dérive, diffusés sous licence ODbL 1.0 (partage à l'identique). Les fichiers suffixés _odbl et les données intégrées à l'atlas, qui contiennent ces indicateurs, sont sous ODbL. Les rapports et les cartes qui les affichent contiennent des informations issues de cette base sous ODbL.

Les fichiers dont le nom finit par _odbl contiennent des données de l'Assurance Maladie (Cnam, data.ameli.fr) et sont diffusés sous la licence Open Database License (ODbL) 1.0, https://opendatacommons.org/licenses/odbl/1-0/. Toute base qui en dérive doit être partagée sous la même licence. Les autres fichiers sont sous Licence Ouverte 2.0 (Etalab), https://www.etalab.gouv.fr/licence-ouverte-open-licence/.

## Comment citer

Pithon L. (2026). Offre de soins et santé mentale en France par territoire, données agrégées. Version du 30 octobre 2026. Zenodo. https://doi.org/10.5281/zenodo.23812351. Toutes les versions, https://doi.org/10.5281/zenodo.23264933.

## Sources

- Référentiel Etalab, Etalab, d'après le Code officiel géographique et les populations légales de l'INSEE, Licence Ouverte 2.0, données du 2026-03-09, https://github.com/etalab/decoupage-administratif
- RPPS activité, Agence du numérique en santé (ANS), Licence Ouverte 2.0, données du 2026-10-29, https://www.data.gouv.fr/datasets/annuaire-sante-extractions-des-donnees-en-libre-acces-des-professionnels-intervenant-dans-le-systeme-de-sante-rpps
- RPPS diplômes, Agence du numérique en santé (ANS), Licence Ouverte 2.0, données du 2026-10-29, https://www.data.gouv.fr/datasets/annuaire-sante-extractions-des-donnees-en-libre-acces-des-professionnels-intervenant-dans-le-systeme-de-sante-rpps
- FINESS (Finess+), Agence du numérique en santé (ANS), Licence Ouverte 2.0, données du 2026-10-01, https://www.data.gouv.fr/datasets/finess-structures-1
- INSEE dossier complet, INSEE, Licence Ouverte 2.0, données du 2026-09-03, https://www.insee.fr/fr/statistiques/5359146
- Assurance Maladie, pathologies, Caisse nationale de l'Assurance Maladie (Cnam), ODbL 1.0 (partage à l'identique), données du 2026-10-28, https://data.ameli.fr/explore/dataset/effectifs/
- Santé publique France, décès par suicide, Santé publique France, Licence Ouverte 2.0, données du 2026-01-09, https://odisse.santepubliquefrance.fr/explore/dataset/suicides-deces-departement/
- Santé publique France, personnes hospitalisées pour geste auto-infligé, Santé publique France, Licence Ouverte 2.0, données du 2026-09-09, https://odisse.santepubliquefrance.fr/explore/dataset/gestes-auto-infliges-patients-hospitalises-departement/
- Santé publique France, passages aux urgences pour geste auto-infligé, Santé publique France, Licence Ouverte 2.0, données du 2025-12-09, https://odisse.santepubliquefrance.fr/explore/dataset/gestes-auto-infliges-passages-aux-urgences-departement/
- Santé publique France, adultes déclarant un épisode dépressif dans l'année, Santé publique France, Licence Ouverte 2.0, données du 2024-12-09, https://odisse.santepubliquefrance.fr/explore/dataset/sante-mentale-episodes-depressifs-caracterises-dans-les-12-derniers-mois_reg/
- Santé publique France, adultes déclarant des pensées suicidaires dans l'année, Santé publique France, Licence Ouverte 2.0, données du 2025-12-11, https://odisse.santepubliquefrance.fr/explore/dataset/conduites-suicidaires-indicateurs-du-barometre-de-sante-publique-france-2024-detail-region/
- Santé publique France, adultes déclarant une tentative de suicide au cours de la vie, Santé publique France, Licence Ouverte 2.0, données du 2025-12-11, https://odisse.santepubliquefrance.fr/explore/dataset/conduites-suicidaires-indicateurs-du-barometre-de-sante-publique-france-2024-detail-region/
- Santé publique France, adultes qui dépassent les repères de consommation d'alcool, Santé publique France, Licence Ouverte 2.0, données du 2025-12-11, https://odisse.santepubliquefrance.fr/explore/dataset/alcool-indicateurs-du-barometre-de-sante-publique-france-2024-detail-region/
- Santé publique France, adultes qui fument chaque jour, Santé publique France, Licence Ouverte 2.0, données du 2025-01-23, https://odisse.santepubliquefrance.fr/explore/dataset/tabac-consommation-quotidienne_reg/
- Santé publique France, décès attribuables au tabac, Santé publique France, Licence Ouverte 2.0, données du 2026-06-26, https://odisse.santepubliquefrance.fr/explore/dataset/tabac-deces-attribuables-au-tabac_reg/
- Assurance Maladie, secteurs conventionnels, Caisse nationale de l'Assurance Maladie (Cnam), ODbL 1.0 (partage à l'identique), données du 2026-10-28, https://data.ameli.fr/explore/dataset/demographie-secteurs-conventionnels/
- Assurance Maladie, montants des honoraires, Caisse nationale de l'Assurance Maladie (Cnam), ODbL 1.0 (partage à l'identique), données du 2026-10-28, https://data.ameli.fr/explore/dataset/honoraires/
- Assurance Maladie, affection longue durée sans médecin traitant, Caisse nationale de l'Assurance Maladie (Cnam), ODbL 1.0 (partage à l'identique), données du 2025-01-28, https://data.ameli.fr/explore/dataset/patients-longueduree-annuelle/
- DREES, protection de l'enfance, DREES, Licence Ouverte 2.0, données du 2026-10-06, https://data.drees.solidarites-sante.gouv.fr/explore/dataset/596_enfance-et-jeunesse-en-danger/
- DREES, personnes en situation de handicap, DREES, Licence Ouverte 2.0, données du 2026-10-06, https://data.drees.solidarites-sante.gouv.fr/explore/dataset/627_personnes-en-situation-de-handicap/
- DREES, SAE psychiatrie, DREES, Licence Ouverte 2.0, données du 2025-12-17, https://data.drees.solidarites-sante.gouv.fr/explore/dataset/708_bases-statistiques-sae/
- Assurance Maladie, affections de longue durée, Caisse nationale de l'Assurance Maladie (Cnam), Licence Ouverte 1.0, données du 2025-12-12, https://www.data.gouv.fr/datasets/beneficiaires-du-dispositif-des-affections-de-longue-duree-ald
- CAF, allocataires par prestation, Caisse nationale des allocations familiales (CNAF), Licence Ouverte 2.0, données du 2026-02-11, https://data.caf.fr/explore/dataset/s_ben_epci_f/
- DREES, démographie des professionnels de santé, DREES, Licence Ouverte 2.0, données du 2026-07-02, https://data.drees.solidarites-sante.gouv.fr/explore/dataset/la-demographie-des-professionnels-de-sante-depuis-2012/information/
- DREES, démographie des professionnels de santé, âge des professionnels, DREES, Licence Ouverte 2.0, https://data.drees.solidarites-sante.gouv.fr/explore/dataset/la-demographie-des-professionnels-de-sante-depuis-2012/information/
- INSEE, temps d'accès par la route, INSEE, Licence Ouverte 2.0 (distancier fondé sur OpenStreetMap, © ses contributeurs), données du 2026-08-19, https://www.data.gouv.fr/datasets/donnees-sur-la-localisation-et-lacces-de-la-population-aux-equipements
- DREES, accessibilité potentielle localisée, DREES, Licence Ouverte 2.0, données du 2026-07-21, https://data.drees.solidarites-sante.gouv.fr/explore/dataset/530_l-accessibilite-potentielle-localisee-apl/
- Contours des communes (IGN), IGN, ADMIN EXPRESS COG CARTO PE, Licence Ouverte 2.0, données du 2026-10-19, https://www.data.gouv.fr/datasets/admin-express-admin-express-cog-admin-express-cog-carto-admin-express-cog-carto-pe-admin-express-cog-carto-plus-pe
- ANS, offres de santé (ROR), Agence du numérique en santé (ANS), Répertoire opérationnel des ressources, Licence Ouverte 2.0, données du 2026-10-26, https://www.data.gouv.fr/datasets/offres-de-sante-sanitaire-medico-social-et-de-ville-en-france-metropolitaine-et-drom-1
- HAS, certification des établissements de santé, sites rattachés, Haute Autorité de santé (HAS), Licence Ouverte 2.0, données du 2026-10-29, https://www.data.gouv.fr/datasets/certification-des-etablissements-de-sante-pour-la-qualite-des-soins-referentiel-deploye-2021-2025
- INSEE, répertoire Sirene, établissements des gestionnaires de FINESS, Institut national de la statistique et des études économiques (INSEE), Licence Ouverte 2.0, données du 2026-10-01, https://www.data.gouv.fr/datasets/base-sirene-des-entreprises-et-de-leurs-etablissements-siren-siret
- HAS, évaluation des établissements et services médico-sociaux, Haute Autorité de santé (HAS), Licence Ouverte 2.0, données du 2026-10-22, https://www.data.gouv.fr/datasets/resultats-devaluation-des-etablissements-et-services-sociaux-et-medico-sociaux-essms
- Sectorisation psychiatrique, Hauts-de-France, Agence régionale de santé des Hauts-de-France, document administratif communiqué (CRPA), données du 2023-12-26
- INSEE, estimations de population, INSEE, Licence Ouverte 2.0, données du 2026-08-05, https://catalogue-donnees.insee.fr/fr/catalogue/recherche/DS_ESTIMATION_POPULATION
