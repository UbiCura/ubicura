# Dictionnaire des colonnes

Tous les fichiers CSV utilisent le point-virgule comme séparateur et la virgule comme séparateur décimal, pour s'ouvrir directement dans un tableur.

## accessibilite.csv

Distance au professionnel le plus proche, résumée par profession (part des habitants à plus de 5, 10, 20 et 30 km).

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `part_population_dans_la_commune` | Part des habitants qui ont au moins un professionnel dans leur commune. |
| `distance_mediane_km` | Distance médiane des habitants à la structure la plus proche, en km, à vol d'oiseau, cherchée sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucune. |
| `distance_moyenne_km` | Distance médiane ou moyenne des habitants au professionnel le plus proche (km), sans traverser la mer, la moyenne sur les seuls habitants dont le territoire compte au moins un de ces professionnels. |
| `part_population_a_plus_de_5_km` | Part des habitants à plus de 5 km du professionnel le plus proche. |
| `part_population_a_plus_de_10_km` | Part des habitants à plus de 10 km du professionnel le plus proche. |
| `part_population_a_plus_de_20_km` | Part des habitants à plus de 20 km du professionnel le plus proche. |
| `part_population_a_plus_de_30_km` | Part des habitants à plus de 30 km du professionnel le plus proche. |

## accessibilite_communes.csv

Distance au professionnel le plus proche et accessibilité potentielle à deux étapes, par commune.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `epci` | Code SIREN de l'intercommunalité. |
| `dep` | Code du département. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `distance_km` | Distance à vol d'oiseau (km) entre le centre de la commune et celui de la commune la plus proche où exerce au moins un professionnel, sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucun. |
| `accessibilite` | Accessibilité potentielle à deux étapes, en professionnels pour 10 000 habitants. |
| `accessibilite_liberale` | Même calcul limité aux professionnels libéraux, pour comparer avec l'APL de la DREES (cinq professions seulement). |

## accessibilite_epci.csv

Distance moyenne et accessibilité moyenne des habitants, par intercommunalité.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `epci` | Code SIREN de l'intercommunalité. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `distance_moyenne_km` | Distance médiane ou moyenne des habitants au professionnel le plus proche (km), sans traverser la mer, la moyenne sur les seuls habitants dont le territoire compte au moins un de ces professionnels. |
| `accessibilite` | Accessibilité potentielle à deux étapes, en professionnels pour 10 000 habitants. |

## acp_charges.csv

Corrélation de chaque profession avec les premiers axes de l'analyse en composantes principales.

| Colonne | Description |
|---|---|
| `famille` | Famille, « Santé mentale » ou « Santé » (dans les fichiers de la typologie, sm, sante ou tout). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `axe` | Numéro de l'axe de l'analyse en composantes principales. |
| `correlation` | Corrélation de la profession avec l'axe, de -1 à +1. |

## acp_inertie.csv

Valeur propre et part des différences entre intercommunalités résumée par chaque axe de l'analyse en composantes principales.

| Colonne | Description |
|---|---|
| `famille` | Famille, « Santé mentale » ou « Santé » (dans les fichiers de la typologie, sm, sante ou tout). |
| `axe` | Numéro de l'axe de l'analyse en composantes principales. |
| `valeur_propre` | Valeur propre de l'axe (variance qu'il résume, sur des données centrées et réduites). |
| `part_inertie` | Part des différences entre intercommunalités résumée par l'axe. |

## activites_particulieres.csv

Professionnels qui déclarent des activités sans soins à la population (retirées des densités) ou pour un public particulier (gardées), en France.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `personnes` | Personnes distinctes. |
| `sans_autre_lieu_de_soins` | Personnes comptées dans aucune densité, car toutes leurs activités avec un lieu d'exercice sont de cette catégorie (même définition que a_distance_seulement et sans_soins_seulement de parcours_activites.csv). |
| `categorie` | Catégorie d'établissement, libellé d'affichage. |
| `part_profession` | Part de la profession en France. |
| `libelle` | Libellé de la profession. |
| `categorie_libelle` | Libellé de la catégorie. |

## activites_particulieres_dep.csv

Mêmes activités comptées par territoire (département).

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `categorie` | Catégorie d'établissement, libellé d'affichage. |
| `n` | Nombre de personnes distinctes. |
| `nom` | Nom du territoire. |
| `libelle` | Libellé de la profession. |
| `categorie_libelle` | Libellé de la catégorie. |

## activites_particulieres_epci.csv

Mêmes activités comptées par territoire (intercommunalité).

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `categorie` | Catégorie d'établissement, libellé d'affichage. |
| `n` | Nombre de personnes distinctes. |
| `nom` | Nom du territoire. |
| `libelle` | Libellé de la profession. |
| `categorie_libelle` | Libellé de la catégorie. |

## activites_particulieres_reg.csv

Mêmes activités comptées par territoire (région).

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `categorie` | Catégorie d'établissement, libellé d'affichage. |
| `n` | Nombre de personnes distinctes. |
| `nom` | Nom du territoire. |
| `libelle` | Libellé de la profession. |
| `categorie_libelle` | Libellé de la catégorie. |

## age_professionnels.csv

Part des professionnels de 60 ans et plus, par profession, en France et par département, première et dernière année des séries de la DREES.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `annee` | Année des données (pour le fichier des diplômes, année d'obtention, non disponible dans l'extraction publique actuelle). |
| `effectif` | Effectif (personnes distinctes, somme sur les territoires pour inegalites.csv). |
| `plus_60` | Professionnels de 60 ans et plus (DREES). |
| `somme_tranches` | Somme des tranches d'âge, contrôle face à l'effectif publié. |
| `part_60` | Part des professionnels de 60 ans et plus. |
| `indicateur` | Identifiant de l'indicateur (voir les indicateurs de contexte). |
| `libelle` | Libellé de la profession. |
| `professions` | Identifiants des professions additionnées ici pour la comparaison avec la DREES. |

## ald_departements.csv

Personnes en affection de longue durée (ALD) par département, pour les 30 affections de la liste, d'après l'Assurance Maladie (régime général, Licence Ouverte). Effectifs arrondis à la dizaine et taux standardisés sur l'âge. Une ALD mesure une maladie reconnue, pas toutes les personnes malades.

| Colonne | Description |
|---|---|
| `annee` | Année des données (pour le fichier des diplômes, année d'obtention, non disponible dans l'extraction publique actuelle). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `ald` | Numéro de l'affection dans la liste des ALD (1 à 30). |
| `libelle_officiel` | Libellé officiel de l'affection dans la liste des ALD. |
| `secret` | Vrai si l'effectif est inférieur à 10 et n'est pas publié par l'Assurance Maladie. |
| `effectif` | Effectif (personnes distinctes, somme sur les territoires pour inegalites.csv). |
| `taux_standardise` | Personnes en ALD pour 100 000 personnes protégées du régime général, taux standardisé sur l'âge. |
| `nom` | Nom du territoire. |

## allocataires_caf.csv

Bénéficiaires de l'AAH et de l'AEEH, et population couverte par le RSA, d'après la CAF (décembre), par intercommunalité, département et région, avec l'effectif, la population du territoire et la valeur rapportée. Les allocataires du régime agricole (MSA) ne sont pas comptés.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `indicateur` | Identifiant de l'indicateur (voir les indicateurs de contexte). |
| `mois` | Mois de référence des données de la CAF (décembre). |
| `effectif` | Effectif (personnes distinctes, somme sur les territoires pour inegalites.csv). |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `valeur` | Valeur de l'indicateur, dans l'unité indiquée par le dictionnaire des indicateurs. |

## categories_etablissements.csv

Effectifs salariés par catégorie d'établissement FINESS, France et départements.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `categorie_libelle_officiel` | Catégorie d'établissement, libellé officiel de la nomenclature FINESS. |
| `agregat_libelle_officiel` | Agrégat de catégories, libellé officiel de la nomenclature FINESS. |
| `n` | Nombre de personnes distinctes. |
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `categorie` | Catégorie d'établissement, libellé d'affichage. |
| `agregat` | Agrégat de catégories, libellé d'affichage. |

## charge_cmp_sae.csv

File active ambulatoire et psychiatres salariés en temps plein rapportés aux CMP que les établissements déclarent à la statistique annuelle des établissements de santé (SAE), par discipline. Département du siège de l'établissement. La file active ambulatoire compte aussi les patients vus hors CMP (CATTP, consultations, liaison).

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `public` | Public de la discipline, adultes (psychiatrie générale) ou enfants (psychiatrie infanto-juvénile). |
| `cmp_sae` | CMP déclarés à la SAE par les établissements de la discipline. |
| `file_active_ambulatoire` | Patients vus au moins une fois dans l'année en ambulatoire, déclarés à la SAE. |
| `etp_psychiatres` | Psychiatres salariés en équivalents temps plein, déclarés à la SAE. |
| `patients_par_cmp` | File active ambulatoire rapportée au nombre de CMP déclarés. |
| `etp_psychiatres_par_cmp` | Psychiatres salariés en temps plein rapportés au nombre de CMP déclarés. |
| `nom` | Nom du territoire. |

## classes_densite.csv

Densités de professionnels par classe de densité de population.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `classe` | Classe de densité de population ou groupe de la typologie. |
| `territoires` | Nombre de territoires. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `densite_mediane` | Densité médiane des territoires de la classe. |
| `densite_agregee` | Effectif total de la classe rapporté à sa population, pour 10 000 habitants. |

## cmp_par_public.csv

Centres médico-psychologiques par public, pour adultes, pour enfants et adolescents, accueillant les deux, au public non précisé, par territoire.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `cmp` | Centres médico-psychologiques distincts, tous publics (FINESS et ROR réunis). |
| `adultes` | CMP qui accueillent les adultes, ou les enfants et adolescents (un CMP qui accueille les deux compte dans les deux colonnes). |
| `enfants` | CMP qui accueillent les adultes, ou les enfants et adolescents (un CMP qui accueille les deux compte dans les deux colonnes). |
| `les_deux` | CMP qui accueillent à la fois les adultes et les enfants. |
| `non_precise` | CMP connus de FINESS seul, sans âges déclarés ni indice du public dans leur nom. |
| `antennes` | CMP dont le nom dit qu'il s'agit d'une antenne ou d'une permanence (en mairie, en CCAS, en maison de santé), comptés parmi les CMP et signalés comme tels. |

## combinaisons.csv

Combinaisons de présence du médecin généraliste, du psychologue et du psychiatre, par commune et par intercommunalité.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `medecin_generaliste` | Présence (True) ou absence (False) de la profession. |
| `psychologue` | Présence (True) ou absence (False) de la profession. |
| `psychiatre` | Présence (True) ou absence (False) de la profession. |
| `territoires` | Nombre de territoires. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `part_population` | Part de la population. |

## comparaison_apl.csv

Ressemblance entre l'accessibilité calculée ici et l'accessibilité potentielle localisée (APL) de la DREES.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `annee_apl` | Millésime de l'APL publiée par la DREES. |
| `communes` | Nombre de communes comparées. |
| `rho_communes` | Corrélation de rang entre les deux indicateurs, calculée sur les communes. |
| `intercommunalites` | Nombre d'intercommunalités comparées. |
| `rho_epci` | Corrélation de rang entre les deux indicateurs, calculée sur les intercommunalités. |
| `rho_densite_epci` | Corrélation de rang entre la densité simple et l'APL, sur les intercommunalités. |

## comparaison_route.csv

Ressemblance, commune par commune, entre la distance à vol d'oiseau calculée ici et le temps de trajet de l'INSEE.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `equipement` | Type d'équipement ou de professionnel libéral de la base permanente des équipements (INSEE). |
| `communes` | Nombre de communes comparées. |
| `rho_spearman` | Corrélation de rang de Spearman. |

## composition_sante_mentale.csv

Psychologues et psychiatres par territoire, et nombre de psychologues pour un psychiatre.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `psychologues` | Nombre de psychologues. |
| `psychiatres` | Nombre de psychiatres. |
| `psychologues_par_psychiatre` | Nombre de psychologues pour un psychiatre (vide sans psychiatre). |

## concentration_distance_lieux.csv

Indice de concentration de la distance aux structures de soins selon le niveau de vie des intercommunalités, avec sa fourchette.

| Colonne | Description |
|---|---|
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `indice_concentration` | Indice de concentration selon le niveau de vie (0 égalité, positif en faveur des territoires aisés). |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `intercommunalites` | Nombre d'intercommunalités comparées. |
| `libelle_type` | Libellé du type de structure de soins. |

## concentration_revenu.csv

Indice de concentration des professionnels selon le niveau de vie des territoires, avec intervalle de confiance.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `mode` | Mode d'exercice, all (tous), lib (libéral), sal (salarié), aut (autre, bénévole). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `indice_concentration` | Indice de concentration selon le niveau de vie (0 égalité, positif en faveur des territoires aisés). |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `territoires` | Nombre de territoires. |

## concordance_besoins.csv

Corrélation de rang entre deux indicateurs de besoin ou de recours aux soins en santé mentale, entre départements. Montre si les approches du besoin vont dans le même sens.

| Colonne | Description |
|---|---|
| `variable_a` | Identifiant de l'indicateur comparé (voir les indicateurs de contexte). |
| `variable_b` | Identifiant de l'indicateur comparé (voir les indicateurs de contexte). |
| `rho` | Corrélation de rang de Spearman. |
| `departements` | Nombre de départements comparés. |

## concordance_besoins_odbl.csv

Corrélation de rang entre deux indicateurs de besoin ou de recours aux soins en santé mentale, entre départements. Montre si les approches du besoin vont dans le même sens. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `variable_a` | Identifiant de l'indicateur comparé (voir les indicateurs de contexte). |
| `variable_b` | Identifiant de l'indicateur comparé (voir les indicateurs de contexte). |
| `rho` | Corrélation de rang de Spearman. |
| `departements` | Nombre de départements comparés. |

## concordance_cattp_sae.csv

CATTP recensés par FINESS et le ROR confrontés aux CATTP que les établissements déclarent à la SAE de la DREES, par département et région.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `cattp` | CATTP recensés ici (FINESS et ROR réunis). |
| `sae_cattp` | CATTP déclarés à la SAE, par l'établissement ou dans le territoire (département ou région du siège de l'établissement). |
| `sae_cattp_adultes` | CATTP déclarés à la SAE en psychiatrie générale (adultes) ou infanto-juvénile (enfants et adolescents). |
| `sae_cattp_enfants` | CATTP déclarés à la SAE en psychiatrie générale (adultes) ou infanto-juvénile (enfants et adolescents). |
| `ecart_relatif` | Écart relatif entre les structures recensées ici (CMP ou CATTP selon le fichier) et celles déclarées à la SAE. |
| `concordance` | Niveau de concordance des sources, d'après l'écart avec la SAE (20 % et 40 %). |

## concordance_cmp_etablissements.csv

CMP et CATTP confrontés hôpital par hôpital (entité juridique) aux déclarations de la SAE, pour repérer les établissements à vérifier.

| Colonne | Description |
|---|---|
| `ej` | Numéro FINESS de l'entité juridique (l'hôpital ou l'association gestionnaire). |
| `nom` | Nom du territoire. |
| `dep_siege` | Département du siège de l'établissement d'après la SAE. |
| `sae_cmp` | Centres médico-psychologiques (CMP) (pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_adultes` | CMP déclarés à la SAE (bordereau psychiatrie), en tout, en psychiatrie générale (adultes) ou infanto-juvénile (enfants et adolescents), dans le département ou la région du siège de l'établissement. |
| `sae_enfants` | CMP déclarés à la SAE (bordereau psychiatrie), en tout, en psychiatrie générale (adultes) ou infanto-juvénile (enfants et adolescents), dans le département ou la région du siège de l'établissement. |
| `ici_cmp` | CMP (tous, pour adultes, pour enfants) ou CATTP recensés ici et rattachés à l'établissement. |
| `ici_adultes` | CMP (tous, pour adultes, pour enfants) ou CATTP recensés ici et rattachés à l'établissement. |
| `ici_enfants` | CMP (tous, pour adultes, pour enfants) ou CATTP recensés ici et rattachés à l'établissement. |
| `unites_ror` | Unités déclarées comme CMP dans le ROR, avant leur réunion en lieux (plusieurs unités d'un même CMP, ou des CMP déclarés à l'adresse de leur hôpital, ne font qu'une structure). |
| `sae_cattp` | CATTP déclarés à la SAE, par l'établissement ou dans le territoire (département ou région du siège de l'établissement). |
| `ici_cattp` | CMP (tous, pour adultes, pour enfants) ou CATTP recensés ici et rattachés à l'établissement. |
| `ecart` | CMP recensés ici moins CMP déclarés à la SAE. |
| `statut` | Concorde (écart d'au plus 20 % ou d'un CMP), moins ici, plus ici, ou établissement absent de la SAE. |
| `statut_cattp` | Pour les CATTP, concorde (écart d'au plus 20 % ou d'un CATTP), moins ici, plus ici, ou aucun CATTP déclaré à la SAE (l'hôpital y figure sans CATTP, ou n'y figure pas). Vide quand l'hôpital n'a de CATTP ni ici ni à la SAE. |

## concordance_cmp_sae.csv

CMP recensés par FINESS et le ROR confrontés aux CMP que les établissements déclarent à la SAE de la DREES, par département et région.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `cmp` | Centres médico-psychologiques distincts, tous publics (FINESS et ROR réunis). |
| `adultes` | CMP qui accueillent les adultes, ou les enfants et adolescents (un CMP qui accueille les deux compte dans les deux colonnes). |
| `enfants` | CMP qui accueillent les adultes, ou les enfants et adolescents (un CMP qui accueille les deux compte dans les deux colonnes). |
| `les_deux` | CMP qui accueillent à la fois les adultes et les enfants. |
| `non_precise` | CMP connus de FINESS seul, sans âges déclarés ni indice du public dans leur nom. |
| `unites_ror` | Unités déclarées comme CMP dans le ROR, avant leur réunion en lieux (plusieurs unités d'un même CMP, ou des CMP déclarés à l'adresse de leur hôpital, ne font qu'une structure). |
| `sae_cmp` | Centres médico-psychologiques (CMP) (pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_adultes` | CMP déclarés à la SAE (bordereau psychiatrie), en tout, en psychiatrie générale (adultes) ou infanto-juvénile (enfants et adolescents), dans le département ou la région du siège de l'établissement. |
| `sae_enfants` | CMP déclarés à la SAE (bordereau psychiatrie), en tout, en psychiatrie générale (adultes) ou infanto-juvénile (enfants et adolescents), dans le département ou la région du siège de l'établissement. |
| `ecart_relatif` | Écart relatif entre les structures recensées ici (CMP ou CATTP selon le fichier) et celles déclarées à la SAE. |

## concordance_effectifs.csv

Effectifs nationaux rapprochés des séries publiées par la DREES (démographie des professionnels de santé), avec le champ de chaque source et l'explication de l'écart.

| Colonne | Description |
|---|---|
| `libelle` | Libellé de la profession. |
| `professions` | Identifiants des professions additionnées ici pour la comparaison avec la DREES. |
| `mode` | Mode d'exercice, all (tous), lib (libéral), sal (salarié), aut (autre, bénévole). |
| `nous` | Effectif calculé ici, personnes ayant au moins une activité dans l'extraction du RPPS. |
| `date_rpps` | Date de mise à jour de l'extraction du RPPS utilisée. |
| `drees` | Effectif publié par la DREES pour la dernière année disponible. |
| `annee_drees` | Année de l'effectif publié par la DREES. |
| `champ_drees` | Qui la DREES compte dans cette série (répertoire, date, âge, activité). |
| `ecart` | CMP recensés ici moins CMP déclarés à la SAE. |
| `croissance_annuelle_drees` | Croissance de l'effectif entre les deux dernières années publiées par la DREES. |
| `attendu_a_la_date` | Effectif de la DREES prolongé jusqu'à la date de l'extraction du RPPS, à croissance constante. Comparaison pertinente seulement quand la DREES utilise aussi le RPPS. |
| `ecart_a_l_attendu` | Écart relatif entre l'effectif calculé ici et l'effectif prolongé. |
| `explication` | Explication de l'écart par la différence de champ ou de date. |
| `fichier_drees` | Nom du classeur de la DREES lu. |
| `source` | Page du jeu de données chez le producteur. |

## concordance_effectifs_dep.csv

Effectifs par département rapprochés de ceux de la DREES, ressemblance du classement et rapport entre les deux effectifs.

| Colonne | Description |
|---|---|
| `libelle` | Libellé de la profession. |
| `mode` | Mode d'exercice, all (tous), lib (libéral), sal (salarié), aut (autre, bénévole). |
| `annee_drees` | Année de l'effectif publié par la DREES. |
| `departements` | Nombre de départements comparés. |
| `rang_spearman` | Corrélation de rang de Spearman entre les effectifs départementaux calculés ici et ceux de la DREES (1 pour un classement identique). |
| `rapport_median` | Rapport entre l'effectif calculé ici et celui de la DREES, par département (median). |
| `rapport_p10` | Rapport entre l'effectif calculé ici et celui de la DREES, par département (p10). |
| `rapport_p90` | Rapport entre l'effectif calculé ici et celui de la DREES, par département (p90). |
| `rapport_min` | Rapport entre l'effectif calculé ici et celui de la DREES, par département (min). |
| `dep_min` | Code du département où le rapport est le plus bas (min) ou le plus haut (max). |
| `rapport_max` | Rapport entre l'effectif calculé ici et celui de la DREES, par département (max). |
| `dep_max` | Code du département où le rapport est le plus bas (min) ou le plus haut (max). |
| `note` | Différence de définition entre les deux comptages départementaux. |

## concordance_finess_ror.csv

Provenance des structures de soins par département et par type, dans les deux bases, dans FINESS seul ou dans le ROR seul.

| Colonne | Description |
|---|---|
| `dep` | Code du département. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `lieux_les_deux` | Lieux présents dans les deux bases, dans FINESS seul ou dans le ROR seul. |
| `lieux_finess` | Lieux présents dans les deux bases, dans FINESS seul ou dans le ROR seul. |
| `lieux_ror` | Lieux présents dans les deux bases, dans FINESS seul ou dans le ROR seul. |
| `lieux_ror_type` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `lieux_sources` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `lieux_nom_cmp` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `libelle_type` | Libellé du type de structure de soins. |

## contexte_com.csv

Indicateurs de contexte INSEE par commune.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `densite_pop` | Densité de population (hab./km²), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_0_14` | Part des moins de 15 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_15_24` | Part des 15-24 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_65_79` | Part des 65-79 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_80p` | Part des 80 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `revenu_median` | Niveau de vie médian (€), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_pauvrete` | Taux de pauvreté (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_chomage` | Taux de chômage des 15-64 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_cadres` | Part des cadres parmi les 15 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_ouvriers` | Part des ouvriers parmi les 15 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_monoparentales` | Part des familles monoparentales (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_seuls` | Part des 15 ans et plus vivant seuls (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_emploi` | Taux d'emploi des 15-64 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `salaire_moyen` | Salaire net mensuel moyen (€), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_sans_diplome` | Part des personnes sans diplôme (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_emplois_precaires` | Part des emplois à durée limitée (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_logements_suroccupes` | Part des logements suroccupés (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_80p_seuls` | Part des 80 ans et plus vivant seuls (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_logement_social` | Part des ménages locataires d'un logement social (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_minima_sociaux` | Part des minima sociaux dans le revenu disponible (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les départements, régions, vide aux autres niveaux. |

## contexte_dep.csv

Indicateurs de contexte INSEE par département.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `densite_pop` | Densité de population (hab./km²), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_0_14` | Part des moins de 15 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_15_24` | Part des 15-24 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_65_79` | Part des 65-79 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_80p` | Part des 80 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `revenu_median` | Niveau de vie médian (€), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_pauvrete` | Taux de pauvreté (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_chomage` | Taux de chômage des 15-64 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_cadres` | Part des cadres parmi les 15 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_ouvriers` | Part des ouvriers parmi les 15 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_monoparentales` | Part des familles monoparentales (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_seuls` | Part des 15 ans et plus vivant seuls (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_emploi` | Taux d'emploi des 15-64 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `salaire_moyen` | Salaire net mensuel moyen (€), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_sans_diplome` | Part des personnes sans diplôme (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_emplois_precaires` | Part des emplois à durée limitée (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_logements_suroccupes` | Part des logements suroccupés (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_80p_seuls` | Part des 80 ans et plus vivant seuls (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_logement_social` | Part des ménages locataires d'un logement social (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_minima_sociaux` | Part des minima sociaux dans le revenu disponible (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les départements, régions, vide aux autres niveaux. |
| `suicides` | Décès par suicide (pour 100 000 hab., standardisé sur l'âge), source Santé publique France, portail Odissé, d'après le CépiDc (Inserm). Publié pour les départements, vide aux autres niveaux. |
| `hospit_gestes_auto_infliges` | Personnes hospitalisées pour geste auto-infligé (pour 100 000 hab., standardisé sur l'âge), source Santé publique France, portail Odissé, d'après le PMSI-MCO. Publié pour les départements, vide aux autres niveaux. |
| `urgences_gestes_auto_infliges` | Passages aux urgences pour geste auto-infligé (pour 100 000 passages aux urgences), source Santé publique France, portail Odissé, d'après le réseau OSCOUR. Publié pour les départements, vide aux autres niveaux. |
| `entretien_postnatal_precoce` | Femmes ayant eu un entretien postnatal précoce (% des femmes ayant accouché), source Santé publique France, portail Odissé, d'après le SNDS. Publié pour les départements, vide aux autres niveaux. |
| `ase_mesures` | Mesures d'aide sociale à l'enfance (% des jeunes de 0 à 20 ans), source DREES, indicateurs sociaux départementaux, protection de l'enfance. Publié pour les départements, régions, vide aux autres niveaux. |
| `ase_placements` | Enfants accueillis à l'aide sociale à l'enfance (% des jeunes de 0 à 20 ans), source DREES, indicateurs sociaux départementaux, protection de l'enfance. Publié pour les départements, régions, vide aux autres niveaux. |
| `handicap_compensation` | Bénéficiaires d'une prestation de compensation du handicap, moins de 60 ans (pour 1 000 habitants), source DREES, indicateurs sociaux départementaux, personnes en situation de handicap. Publié pour les départements, régions, vide aux autres niveaux. |
| `handicap_places_enfants` | Places en établissement pour enfants en situation de handicap (pour 1 000 moins de 20 ans), source DREES, indicateurs sociaux départementaux, personnes en situation de handicap. Publié pour les départements, régions, vide aux autres niveaux. |
| `handicap_places_sessad` | Places en SESSAD (pour 1 000 moins de 20 ans), source DREES, indicateurs sociaux départementaux, personnes en situation de handicap. Publié pour les départements, régions, vide aux autres niveaux. |
| `eleves_handicap` | Élèves en situation de handicap (pour 1 000 élèves), source DREES, indicateurs sociaux départementaux, personnes en situation de handicap. Publié pour les départements, vide aux autres niveaux. |
| `sae_lits_psy` | Lits d'hospitalisation à temps plein en psychiatrie (pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_places_jour_psy` | Places d'hospitalisation de jour ou de nuit en psychiatrie (pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_cmp` | Centres médico-psychologiques (CMP) (pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_etp_psychiatres` | Psychiatres salariés en psychiatrie hospitalière, en temps plein (ETP pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_etp_psychologues` | Psychologues en psychiatrie hospitalière, en temps plein (ETP pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_file_active` | Patients suivis en psychiatrie hospitalière (file active) (pour 1 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_infanto` | Lits et places en psychiatrie de l'enfant et de l'adolescent (pour 100 000 moins de 15 ans), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `ald_23` | Affections psychiatriques de longue durée (ALD 23) (pour 100 000 (standardisé)), source Assurance Maladie, affections de longue durée. Publié pour les départements, vide aux autres niveaux. |
| `ald_15` | Maladie d'Alzheimer et autres démences (ALD 15) (pour 100 000 (standardisé)), source Assurance Maladie, affections de longue durée. Publié pour les départements, vide aux autres niveaux. |
| `ald_8` | Diabète (ALD 8) (pour 100 000 (standardisé)), source Assurance Maladie, affections de longue durée. Publié pour les départements, vide aux autres niveaux. |
| `ald_30` | Cancers (tumeurs malignes) (ALD 30) (pour 100 000 (standardisé)), source Assurance Maladie, affections de longue durée. Publié pour les départements, vide aux autres niveaux. |
| `ald_5` | Maladies cardiaques graves (ALD 5) (pour 100 000 (standardisé)), source Assurance Maladie, affections de longue durée. Publié pour les départements, vide aux autres niveaux. |
| `ald_13` | Maladie coronaire (ALD 13) (pour 100 000 (standardisé)), source Assurance Maladie, affections de longue durée. Publié pour les départements, vide aux autres niveaux. |
| `ald_1` | Accident vasculaire cérébral invalidant (ALD 1) (pour 100 000 (standardisé)), source Assurance Maladie, affections de longue durée. Publié pour les départements, vide aux autres niveaux. |
| `ald_14` | Insuffisance respiratoire chronique grave (ALD 14) (pour 100 000 (standardisé)), source Assurance Maladie, affections de longue durée. Publié pour les départements, vide aux autres niveaux. |
| `ald_16` | Maladie de Parkinson (ALD 16) (pour 100 000 (standardisé)), source Assurance Maladie, affections de longue durée. Publié pour les départements, vide aux autres niveaux. |
| `caf_aah` | Bénéficiaires de l'AAH (pour 1 000 habitants), source CAF, allocataires par prestation. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `caf_aeeh` | Bénéficiaires de l'AEEH (pour 1 000 habitants), source CAF, allocataires par prestation. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `caf_rsa` | Population couverte par le RSA (%), source CAF, allocataires par prestation. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `age60_medecins` | Part des 60 ans et plus, médecins, toutes spécialités (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_medecin_generaliste` | Part des 60 ans et plus, médecins généralistes (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_psychiatre` | Part des 60 ans et plus, psychiatres, dont psychiatres de l'enfant (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_pediatre` | Part des 60 ans et plus, pédiatres (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_gynecologue` | Part des 60 ans et plus, gynécologues (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_ophtalmologue` | Part des 60 ans et plus, ophtalmologues (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_cardiologue` | Part des 60 ans et plus, cardiologues (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_dermatologue` | Part des 60 ans et plus, dermatologues (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_ens_medecin_specialiste` | Part des 60 ans et plus, médecins spécialistes, hors généralistes (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_anesthesiste` | Part des 60 ans et plus, anesthésistes-réanimateurs et médecins réanimateurs (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_orl` | Part des 60 ans et plus, oto-rhino-laryngologistes (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_gastro_enterologue` | Part des 60 ans et plus, gastro-entérologues (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_pneumologue` | Part des 60 ans et plus, pneumologues (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_chirurgiens` | Part des 60 ans et plus, chirurgiens (hors orl, ophtalmologie et gynécologie) (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_chirurgien_dentiste` | Part des 60 ans et plus, chirurgiens-dentistes (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_masseur_kinesitherapeute` | Part des 60 ans et plus, masseurs-kinésithérapeutes (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_sage_femme` | Part des 60 ans et plus, sages-femmes (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_pharmacien` | Part des 60 ans et plus, pharmaciens (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_pedicure_podologue` | Part des 60 ans et plus, pédicures-podologues (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `age60_infirmier_liberal` | Part des 60 ans et plus, infirmiers libéraux (%), source DREES, démographie des professionnels de santé. Publié pour les départements, vide aux autres niveaux. |
| `lieux_lieu_cmp_adultes` | CMP pour adultes, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cmp_enfants` | CMP pour enfants et adolescents, pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cattp` | CATTP, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_hdj_psy_adultes` | Hôpitaux de jour en psychiatrie (adultes), pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_hdj_psy_enfants` | Hôpitaux de jour en psychiatrie (enfants et adolescents), pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_hc_psy_adultes` | Hospitalisation complète en psychiatrie, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cmpp` | CMPP, pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_camsp` | CAMSP, pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_csapa` | CSAPA, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_caarud` | CAARUD, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_urgences` | Services d'urgences, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_maternite` | Maternités, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_ehpad` | EHPAD, pour 100 000 personnes de 80 ans et plus (pour 100 000 personnes de 80 ans et plus), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_ime` | Instituts médico-éducatifs (IME), pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_sessad` | Services d'éducation spéciale et de soins à domicile (SESSAD), pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_msp` | Maisons de santé pluriprofessionnelles, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_centre_sante` | Centres de santé, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmp_adultes` | Distance à la structure la plus proche, CMP pour adultes (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmp_enfants` | Distance à la structure la plus proche, CMP pour enfants et adolescents (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cattp` | Distance à la structure la plus proche, CATTP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hdj_psy_adultes` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (adultes) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hdj_psy_enfants` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (enfants et adolescents) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hc_psy_adultes` | Distance à la structure la plus proche, hospitalisation complète en psychiatrie (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmpp` | Distance à la structure la plus proche, CMPP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_camsp` | Distance à la structure la plus proche, CAMSP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_csapa` | Distance à la structure la plus proche, CSAPA (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_caarud` | Distance à la structure la plus proche, CAARUD (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_urgences` | Distance à la structure la plus proche, services d'urgences (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_maternite` | Distance à la structure la plus proche, maternités (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_ehpad` | Distance à la structure la plus proche, EHPAD (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_ime` | Distance à la structure la plus proche, instituts médico-éducatifs (IME) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_sessad` | Distance à la structure la plus proche, services d'éducation spéciale et de soins à domicile (SESSAD) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_msp` | Distance à la structure la plus proche, maisons de santé pluriprofessionnelles (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_centre_sante` | Distance à la structure la plus proche, centres de santé (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_cmp_enfants` | Distance à la structure la plus proche, CMP pour enfants et adolescents, pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_hdj_psy_enfants` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (enfants et adolescents), pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_cmpp` | Distance à la structure la plus proche, CMPP, pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_camsp` | Distance à la structure la plus proche, CAMSP, pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_maternite` | Distance à la structure la plus proche, maternités, depuis le domicile des mères (enfants nés de 2017 à 2022) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, état civil et recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_ime` | Distance à la structure la plus proche, instituts médico-éducatifs (IME), pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_sessad` | Distance à la structure la plus proche, services d'éducation spéciale et de soins à domicile (SESSAD), pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |

## contexte_dep_odbl.csv

Indicateurs de contexte INSEE par département. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `pec_troubles_psy` | Personnes prises en charge pour troubles psychiques (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_psychotiques` | Personnes prises en charge pour troubles psychotiques (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_humeur` | Personnes prises en charge pour troubles névrotiques et de l'humeur (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_deficience` | Personnes prises en charge pour déficience intellectuelle (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_addictions` | Personnes prises en charge pour troubles addictifs (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_enfance` | Personnes prises en charge pour troubles débutant dans l'enfance (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_autres_psy` | Personnes prises en charge pour d'autres troubles psychiques (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `psychotropes` | Personnes sous traitement psychotrope sans trouble psychique repéré (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `antidepresseurs` | Personnes sous antidépresseurs ou thymorégulateurs, sans trouble repéré (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `anxiolytiques` | Personnes sous anxiolytiques, sans trouble repéré (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `hypnotiques` | Personnes sous hypnotiques, sans trouble repéré (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `neuroleptiques` | Personnes sous neuroleptiques, sans trouble repéré (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `depassements_psychiatre` | Psychiatres libéraux pouvant pratiquer des dépassements d'honoraires (%), source Assurance Maladie, effectifs de libéraux par secteur conventionnel (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `depassements_pediatre` | Pédiatres libéraux pouvant pratiquer des dépassements d'honoraires (%), source Assurance Maladie, effectifs de libéraux par secteur conventionnel (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `depassements_medecin_generaliste` | Médecins généralistes libéraux pouvant pratiquer des dépassements d'honoraires (%), source Assurance Maladie, effectifs de libéraux par secteur conventionnel (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `depassements_gynecologue` | Gynécologues libéraux pouvant pratiquer des dépassements d'honoraires (%), source Assurance Maladie, effectifs de libéraux par secteur conventionnel (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `depassements_ophtalmologue` | Ophtalmologues libéraux pouvant pratiquer des dépassements d'honoraires (%), source Assurance Maladie, effectifs de libéraux par secteur conventionnel (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `taux_depassement_psychiatre` | Psychiatres libéraux en secteur 2, dépassements rapportés aux honoraires sans dépassement (%), source Assurance Maladie, montants des honoraires des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `taux_depassement_pediatre` | Pédiatres libéraux en secteur 2, dépassements rapportés aux honoraires sans dépassement (%), source Assurance Maladie, montants des honoraires des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `taux_depassement_medecin_generaliste` | Médecins généralistes libéraux en secteur 2, dépassements rapportés aux honoraires sans dépassement (%), source Assurance Maladie, montants des honoraires des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `taux_depassement_gynecologue` | Gynécologues libéraux en secteur 2, dépassements rapportés aux honoraires sans dépassement (%), source Assurance Maladie, montants des honoraires des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `taux_depassement_ophtalmologue` | Ophtalmologues libéraux en secteur 2, dépassements rapportés aux honoraires sans dépassement (%), source Assurance Maladie, montants des honoraires des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_psychiatre` | Patientèle d'un psychiatre libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_medecin_generaliste` | Patientèle d'un médecin généraliste libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `patients_mt_medecin_generaliste` | Patients qui ont choisi un médecin généraliste libéral comme médecin traitant (patients, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_pediatre` | Patientèle d'un pédiatre libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `patients_mt_pediatre` | Patients qui ont choisi un pédiatre libéral comme médecin traitant (patients, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_gynecologue` | Patientèle d'un gynécologue libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_ophtalmologue` | Patientèle d'un ophtalmologue libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_infirmier` | Patientèle d'un infirmier libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_masseur_kinesitherapeute` | Patientèle d'un masseur-kinésithérapeute libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_orthophoniste` | Patientèle d'un orthophoniste libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_sage_femme` | Patientèle d'une sage-femme libérale (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_chirurgien_dentiste` | Patientèle d'un chirurgien-dentiste libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `ald_sans_medecin_traitant` | Patients en affection longue durée sans médecin traitant (%), source Assurance Maladie, patients en affection longue durée sans médecin traitant (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |

## contexte_epci.csv

Indicateurs de contexte INSEE par intercommunalité.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `densite_pop` | Densité de population (hab./km²), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_0_14` | Part des moins de 15 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_15_24` | Part des 15-24 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_65_79` | Part des 65-79 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_80p` | Part des 80 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `revenu_median` | Niveau de vie médian (€), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_pauvrete` | Taux de pauvreté (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_chomage` | Taux de chômage des 15-64 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_cadres` | Part des cadres parmi les 15 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_ouvriers` | Part des ouvriers parmi les 15 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_monoparentales` | Part des familles monoparentales (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_seuls` | Part des 15 ans et plus vivant seuls (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_emploi` | Taux d'emploi des 15-64 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `salaire_moyen` | Salaire net mensuel moyen (€), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_sans_diplome` | Part des personnes sans diplôme (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_emplois_precaires` | Part des emplois à durée limitée (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_logements_suroccupes` | Part des logements suroccupés (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_80p_seuls` | Part des 80 ans et plus vivant seuls (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_logement_social` | Part des ménages locataires d'un logement social (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_minima_sociaux` | Part des minima sociaux dans le revenu disponible (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les départements, régions, vide aux autres niveaux. |
| `caf_aah` | Bénéficiaires de l'AAH (pour 1 000 habitants), source CAF, allocataires par prestation. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `caf_aeeh` | Bénéficiaires de l'AEEH (pour 1 000 habitants), source CAF, allocataires par prestation. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `caf_rsa` | Population couverte par le RSA (%), source CAF, allocataires par prestation. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cmp_adultes` | CMP pour adultes, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cmp_enfants` | CMP pour enfants et adolescents, pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cattp` | CATTP, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_hdj_psy_adultes` | Hôpitaux de jour en psychiatrie (adultes), pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_hdj_psy_enfants` | Hôpitaux de jour en psychiatrie (enfants et adolescents), pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_hc_psy_adultes` | Hospitalisation complète en psychiatrie, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cmpp` | CMPP, pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_camsp` | CAMSP, pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_csapa` | CSAPA, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_caarud` | CAARUD, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_urgences` | Services d'urgences, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_maternite` | Maternités, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_ehpad` | EHPAD, pour 100 000 personnes de 80 ans et plus (pour 100 000 personnes de 80 ans et plus), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_ime` | Instituts médico-éducatifs (IME), pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_sessad` | Services d'éducation spéciale et de soins à domicile (SESSAD), pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_msp` | Maisons de santé pluriprofessionnelles, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_centre_sante` | Centres de santé, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmp_adultes` | Distance à la structure la plus proche, CMP pour adultes (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmp_enfants` | Distance à la structure la plus proche, CMP pour enfants et adolescents (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cattp` | Distance à la structure la plus proche, CATTP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hdj_psy_adultes` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (adultes) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hdj_psy_enfants` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (enfants et adolescents) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hc_psy_adultes` | Distance à la structure la plus proche, hospitalisation complète en psychiatrie (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmpp` | Distance à la structure la plus proche, CMPP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_camsp` | Distance à la structure la plus proche, CAMSP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_csapa` | Distance à la structure la plus proche, CSAPA (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_caarud` | Distance à la structure la plus proche, CAARUD (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_urgences` | Distance à la structure la plus proche, services d'urgences (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_maternite` | Distance à la structure la plus proche, maternités (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_ehpad` | Distance à la structure la plus proche, EHPAD (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_ime` | Distance à la structure la plus proche, instituts médico-éducatifs (IME) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_sessad` | Distance à la structure la plus proche, services d'éducation spéciale et de soins à domicile (SESSAD) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_msp` | Distance à la structure la plus proche, maisons de santé pluriprofessionnelles (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_centre_sante` | Distance à la structure la plus proche, centres de santé (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_cmp_enfants` | Distance à la structure la plus proche, CMP pour enfants et adolescents, pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_hdj_psy_enfants` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (enfants et adolescents), pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_cmpp` | Distance à la structure la plus proche, CMPP, pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_camsp` | Distance à la structure la plus proche, CAMSP, pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_maternite` | Distance à la structure la plus proche, maternités, depuis le domicile des mères (enfants nés de 2017 à 2022) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, état civil et recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_ime` | Distance à la structure la plus proche, instituts médico-éducatifs (IME), pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_sessad` | Distance à la structure la plus proche, services d'éducation spéciale et de soins à domicile (SESSAD), pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |

## contexte_reg.csv

Indicateurs de contexte INSEE par région.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `densite_pop` | Densité de population (hab./km²), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_0_14` | Part des moins de 15 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_15_24` | Part des 15-24 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_65_79` | Part des 65-79 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_80p` | Part des 80 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `revenu_median` | Niveau de vie médian (€), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_pauvrete` | Taux de pauvreté (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_chomage` | Taux de chômage des 15-64 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_cadres` | Part des cadres parmi les 15 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_ouvriers` | Part des ouvriers parmi les 15 ans et plus (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_monoparentales` | Part des familles monoparentales (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_seuls` | Part des 15 ans et plus vivant seuls (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `taux_emploi` | Taux d'emploi des 15-64 ans (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `salaire_moyen` | Salaire net mensuel moyen (€), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_sans_diplome` | Part des personnes sans diplôme (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_emplois_precaires` | Part des emplois à durée limitée (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_logements_suroccupes` | Part des logements suroccupés (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_80p_seuls` | Part des 80 ans et plus vivant seuls (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_logement_social` | Part des ménages locataires d'un logement social (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les communes, intercommunalités, départements, régions, vide aux autres niveaux. |
| `part_minima_sociaux` | Part des minima sociaux dans le revenu disponible (%), source INSEE, dossier complet (recensement de la population, Filosofi). Publié pour les départements, régions, vide aux autres niveaux. |
| `episode_depressif_declare` | Adultes déclarant un épisode dépressif dans l'année (% des adultes), source Santé publique France, portail Odissé, Baromètre de Santé publique France. Publié pour les régions, vide aux autres niveaux. |
| `trouble_anxieux_generalise` | Adultes présentant un trouble anxieux généralisé, d'après leurs réponses (% des adultes), source Santé publique France, portail Odissé, Baromètre de Santé publique France. Publié pour les régions, vide aux autres niveaux. |
| `satisfaction_vie` | Satisfaction de la vie actuelle, score moyen (sur 10), source Santé publique France, portail Odissé, Baromètre de Santé publique France. Publié pour les régions, vide aux autres niveaux. |
| `pensees_suicidaires_declarees` | Adultes déclarant des pensées suicidaires dans l'année (% des adultes), source Santé publique France, portail Odissé, Baromètre de Santé publique France. Publié pour les régions, vide aux autres niveaux. |
| `tentative_suicide_vie_declaree` | Adultes déclarant une tentative de suicide au cours de la vie (% des adultes), source Santé publique France, portail Odissé, Baromètre de Santé publique France. Publié pour les régions, vide aux autres niveaux. |
| `alcool_depassement_reperes` | Adultes qui dépassent les repères de consommation d'alcool (% des adultes), source Santé publique France, portail Odissé, Baromètre de Santé publique France. Publié pour les régions, vide aux autres niveaux. |
| `tabac_quotidien` | Adultes qui fument chaque jour (% des adultes), source Santé publique France, portail Odissé, Baromètre de Santé publique France. Publié pour les régions, vide aux autres niveaux. |
| `deces_attribuables_tabac` | Décès attribuables au tabac (pour 100 000 hab., standardisé sur l'âge), source Santé publique France, portail Odissé, d'après le CépiDc (Inserm). Publié pour les régions, vide aux autres niveaux. |
| `ase_mesures` | Mesures d'aide sociale à l'enfance (% des jeunes de 0 à 20 ans), source DREES, indicateurs sociaux départementaux, protection de l'enfance. Publié pour les départements, régions, vide aux autres niveaux. |
| `ase_placements` | Enfants accueillis à l'aide sociale à l'enfance (% des jeunes de 0 à 20 ans), source DREES, indicateurs sociaux départementaux, protection de l'enfance. Publié pour les départements, régions, vide aux autres niveaux. |
| `handicap_compensation` | Bénéficiaires d'une prestation de compensation du handicap, moins de 60 ans (pour 1 000 habitants), source DREES, indicateurs sociaux départementaux, personnes en situation de handicap. Publié pour les départements, régions, vide aux autres niveaux. |
| `handicap_places_enfants` | Places en établissement pour enfants en situation de handicap (pour 1 000 moins de 20 ans), source DREES, indicateurs sociaux départementaux, personnes en situation de handicap. Publié pour les départements, régions, vide aux autres niveaux. |
| `handicap_places_sessad` | Places en SESSAD (pour 1 000 moins de 20 ans), source DREES, indicateurs sociaux départementaux, personnes en situation de handicap. Publié pour les départements, régions, vide aux autres niveaux. |
| `eleves_handicap` | Élèves en situation de handicap (pour 1 000 élèves), source DREES, indicateurs sociaux départementaux, personnes en situation de handicap. Publié pour les départements, vide aux autres niveaux. |
| `sae_lits_psy` | Lits d'hospitalisation à temps plein en psychiatrie (pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_places_jour_psy` | Places d'hospitalisation de jour ou de nuit en psychiatrie (pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_cmp` | Centres médico-psychologiques (CMP) (pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_etp_psychiatres` | Psychiatres salariés en psychiatrie hospitalière, en temps plein (ETP pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_etp_psychologues` | Psychologues en psychiatrie hospitalière, en temps plein (ETP pour 100 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_file_active` | Patients suivis en psychiatrie hospitalière (file active) (pour 1 000 habitants), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `sae_infanto` | Lits et places en psychiatrie de l'enfant et de l'adolescent (pour 100 000 moins de 15 ans), source DREES, Statistique annuelle des établissements de santé (SAE), bordereau psychiatrie. Publié pour les départements, régions, vide aux autres niveaux. |
| `caf_aah` | Bénéficiaires de l'AAH (pour 1 000 habitants), source CAF, allocataires par prestation. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `caf_aeeh` | Bénéficiaires de l'AEEH (pour 1 000 habitants), source CAF, allocataires par prestation. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `caf_rsa` | Population couverte par le RSA (%), source CAF, allocataires par prestation. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cmp_adultes` | CMP pour adultes, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cmp_enfants` | CMP pour enfants et adolescents, pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cattp` | CATTP, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_hdj_psy_adultes` | Hôpitaux de jour en psychiatrie (adultes), pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_hdj_psy_enfants` | Hôpitaux de jour en psychiatrie (enfants et adolescents), pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_hc_psy_adultes` | Hospitalisation complète en psychiatrie, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_cmpp` | CMPP, pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_camsp` | CAMSP, pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_csapa` | CSAPA, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_caarud` | CAARUD, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_urgences` | Services d'urgences, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_maternite` | Maternités, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_ehpad` | EHPAD, pour 100 000 personnes de 80 ans et plus (pour 100 000 personnes de 80 ans et plus), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_ime` | Instituts médico-éducatifs (IME), pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_sessad` | Services d'éducation spéciale et de soins à domicile (SESSAD), pour 100 000 enfants de moins de 15 ans (pour 100 000 enfants de moins de 15 ans), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_msp` | Maisons de santé pluriprofessionnelles, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `lieux_lieu_centre_sante` | Centres de santé, pour 100 000 habitants (pour 100 000 hab.), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmp_adultes` | Distance à la structure la plus proche, CMP pour adultes (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmp_enfants` | Distance à la structure la plus proche, CMP pour enfants et adolescents (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cattp` | Distance à la structure la plus proche, CATTP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hdj_psy_adultes` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (adultes) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hdj_psy_enfants` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (enfants et adolescents) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hc_psy_adultes` | Distance à la structure la plus proche, hospitalisation complète en psychiatrie (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmpp` | Distance à la structure la plus proche, CMPP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_camsp` | Distance à la structure la plus proche, CAMSP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_csapa` | Distance à la structure la plus proche, CSAPA (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_caarud` | Distance à la structure la plus proche, CAARUD (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_urgences` | Distance à la structure la plus proche, services d'urgences (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_maternite` | Distance à la structure la plus proche, maternités (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_ehpad` | Distance à la structure la plus proche, EHPAD (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_ime` | Distance à la structure la plus proche, instituts médico-éducatifs (IME) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_sessad` | Distance à la structure la plus proche, services d'éducation spéciale et de soins à domicile (SESSAD) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_msp` | Distance à la structure la plus proche, maisons de santé pluriprofessionnelles (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_centre_sante` | Distance à la structure la plus proche, centres de santé (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_cmp_enfants` | Distance à la structure la plus proche, CMP pour enfants et adolescents, pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_hdj_psy_enfants` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (enfants et adolescents), pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_cmpp` | Distance à la structure la plus proche, CMPP, pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_camsp` | Distance à la structure la plus proche, CAMSP, pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_maternite` | Distance à la structure la plus proche, maternités, depuis le domicile des mères (enfants nés de 2017 à 2022) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, état civil et recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_ime` | Distance à la structure la plus proche, instituts médico-éducatifs (IME), pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `distp_lieu_sessad` | Distance à la structure la plus proche, services d'éducation spéciale et de soins à domicile (SESSAD), pour les enfants de moins de 15 ans (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte ; INSEE, recensement. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |

## contexte_reg_odbl.csv

Indicateurs de contexte INSEE par région. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `pec_troubles_psy` | Personnes prises en charge pour troubles psychiques (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_psychotiques` | Personnes prises en charge pour troubles psychotiques (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_humeur` | Personnes prises en charge pour troubles névrotiques et de l'humeur (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_deficience` | Personnes prises en charge pour déficience intellectuelle (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_addictions` | Personnes prises en charge pour troubles addictifs (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_enfance` | Personnes prises en charge pour troubles débutant dans l'enfance (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `pec_autres_psy` | Personnes prises en charge pour d'autres troubles psychiques (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `psychotropes` | Personnes sous traitement psychotrope sans trouble psychique repéré (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `antidepresseurs` | Personnes sous antidépresseurs ou thymorégulateurs, sans trouble repéré (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `anxiolytiques` | Personnes sous anxiolytiques, sans trouble repéré (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `hypnotiques` | Personnes sous hypnotiques, sans trouble repéré (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `neuroleptiques` | Personnes sous neuroleptiques, sans trouble repéré (% standardisé sur l'âge), source Assurance Maladie, cartographie des pathologies (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `depassements_psychiatre` | Psychiatres libéraux pouvant pratiquer des dépassements d'honoraires (%), source Assurance Maladie, effectifs de libéraux par secteur conventionnel (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `depassements_pediatre` | Pédiatres libéraux pouvant pratiquer des dépassements d'honoraires (%), source Assurance Maladie, effectifs de libéraux par secteur conventionnel (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `depassements_medecin_generaliste` | Médecins généralistes libéraux pouvant pratiquer des dépassements d'honoraires (%), source Assurance Maladie, effectifs de libéraux par secteur conventionnel (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `depassements_gynecologue` | Gynécologues libéraux pouvant pratiquer des dépassements d'honoraires (%), source Assurance Maladie, effectifs de libéraux par secteur conventionnel (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `depassements_ophtalmologue` | Ophtalmologues libéraux pouvant pratiquer des dépassements d'honoraires (%), source Assurance Maladie, effectifs de libéraux par secteur conventionnel (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `taux_depassement_psychiatre` | Psychiatres libéraux en secteur 2, dépassements rapportés aux honoraires sans dépassement (%), source Assurance Maladie, montants des honoraires des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `taux_depassement_pediatre` | Pédiatres libéraux en secteur 2, dépassements rapportés aux honoraires sans dépassement (%), source Assurance Maladie, montants des honoraires des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `taux_depassement_medecin_generaliste` | Médecins généralistes libéraux en secteur 2, dépassements rapportés aux honoraires sans dépassement (%), source Assurance Maladie, montants des honoraires des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `taux_depassement_gynecologue` | Gynécologues libéraux en secteur 2, dépassements rapportés aux honoraires sans dépassement (%), source Assurance Maladie, montants des honoraires des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `taux_depassement_ophtalmologue` | Ophtalmologues libéraux en secteur 2, dépassements rapportés aux honoraires sans dépassement (%), source Assurance Maladie, montants des honoraires des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_psychiatre` | Patientèle d'un psychiatre libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_medecin_generaliste` | Patientèle d'un médecin généraliste libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `patients_mt_medecin_generaliste` | Patients qui ont choisi un médecin généraliste libéral comme médecin traitant (patients, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_pediatre` | Patientèle d'un pédiatre libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `patients_mt_pediatre` | Patients qui ont choisi un pédiatre libéral comme médecin traitant (patients, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_gynecologue` | Patientèle d'un gynécologue libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_ophtalmologue` | Patientèle d'un ophtalmologue libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_infirmier` | Patientèle d'un infirmier libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_masseur_kinesitherapeute` | Patientèle d'un masseur-kinésithérapeute libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_orthophoniste` | Patientèle d'un orthophoniste libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_sage_femme` | Patientèle d'une sage-femme libérale (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `file_active_chirurgien_dentiste` | Patientèle d'un chirurgien-dentiste libéral (patients vus dans l'année, en moyenne), source Assurance Maladie, patientèle des libéraux par territoire (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |
| `ald_sans_medecin_traitant` | Patients en affection longue durée sans médecin traitant (%), source Assurance Maladie, patients en affection longue durée sans médecin traitant (data.ameli.fr, licence ODbL). Publié pour les départements, régions, vide aux autres niveaux. |

## controle_appariement_finess.csv

Contrôle de l'appariement entre le RPPS et FINESS.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `activites_avec_finess` | Activités salariées portant un numéro FINESS. |
| `appariees` | Activités dont le numéro FINESS est retrouvé dans FINESS. |
| `taux` | Part des activités appariées. |

## correlations_contexte.csv

Corrélations entre densité de chaque profession et indicateurs de contexte.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `mode` | Mode d'exercice, all (tous), lib (libéral), sal (salarié), aut (autre, bénévole). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `n` | Nombre de personnes distinctes. |
| `rho_spearman` | Corrélation de rang de Spearman. |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `r_pearson_pondere_log` | Corrélation de Pearson pondérée par la population, sur le logarithme de la densité. |
| `rho_partiel_densite` | Corrélation partielle de rang à densité de population égale (effet ville retiré). |
| `ic95_bas_partiel` | Borne de l'intervalle de confiance à 95 % de la corrélation partielle. |
| `ic95_haut_partiel` | Borne de l'intervalle de confiance à 95 % de la corrélation partielle. |
| `p_partiel` | p-valeur de la corrélation partielle (test t). |
| `q_bh` | q-valeur après correction de Benjamini-Hochberg. |
| `q_bh_partiel` | q-valeur de la corrélation partielle après correction de Benjamini-Hochberg. |
| `force` | Force du lien (négligeable, faible, modérée, forte). |

## correlations_contexte_odbl.csv

Corrélations entre densité de chaque profession et indicateurs de contexte. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `mode` | Mode d'exercice, all (tous), lib (libéral), sal (salarié), aut (autre, bénévole). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `n` | Nombre de personnes distinctes. |
| `rho_spearman` | Corrélation de rang de Spearman. |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `r_pearson_pondere_log` | Corrélation de Pearson pondérée par la population, sur le logarithme de la densité. |
| `rho_partiel_densite` | Corrélation partielle de rang à densité de population égale (effet ville retiré). |
| `ic95_bas_partiel` | Borne de l'intervalle de confiance à 95 % de la corrélation partielle. |
| `ic95_haut_partiel` | Borne de l'intervalle de confiance à 95 % de la corrélation partielle. |
| `p_partiel` | p-valeur de la corrélation partielle (test t). |
| `q_bh` | q-valeur après correction de Benjamini-Hochberg. |
| `q_bh_partiel` | q-valeur de la corrélation partielle après correction de Benjamini-Hochberg. |
| `force` | Force du lien (négligeable, faible, modérée, forte). |

## correlations_professions_dep.csv

Matrice des corrélations de rang entre densités de professions, par département.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession en ligne. |
| `<profession>` | Corrélation de rang de Spearman entre la densité de la profession en ligne et celle de la profession en colonne. |

## correlations_professions_epci.csv

Matrice des corrélations de rang entre densités de professions, par intercommunalité.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession en ligne. |
| `<profession>` | Corrélation de rang de Spearman entre la densité de la profession en ligne et celle de la profession en colonne. |

## croisements.csv

Croisements départementaux entre une mesure de l'offre et un indicateur du profil ou du besoin, corrélation de rang brute et à densité de population égale, avec intervalles de confiance par bootstrap.

| Colonne | Description |
|---|---|
| `theme` | Thème du croisement. |
| `mesure` | Résultat recalculé (nombre, distance médiane, part à plus de 20 km, classement des départements, éloignement selon le niveau de vie). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `departements` | Nombre de départements comparés. |
| `rho` | Corrélation de rang de Spearman. |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `rho_partiel_densite` | Corrélation partielle de rang à densité de population égale (effet ville retiré). |
| `ic95_bas_partiel` | Borne de l'intervalle de confiance à 95 % de la corrélation partielle. |
| `ic95_haut_partiel` | Borne de l'intervalle de confiance à 95 % de la corrélation partielle. |

## croisements_indicateurs.csv

Corrélation de rang entre chaque paire d'indicateurs de santé mentale, de recours aux soins et de vulnérabilité, par département, avec intervalle de confiance, correction de Benjamini-Hochberg et valeur sans l'Île-de-France.

| Colonne | Description |
|---|---|
| `variable_a` | Identifiant de l'indicateur comparé (voir les indicateurs de contexte). |
| `variable_b` | Identifiant de l'indicateur comparé (voir les indicateurs de contexte). |
| `departements` | Nombre de départements comparés. |
| `rho` | Corrélation de rang de Spearman. |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `rho_sans_ile_de_france` | Corrélation de rang sans les huit départements d'Île-de-France. |
| `q_bh` | q-valeur après correction de Benjamini-Hochberg. |

## croisements_indicateurs_odbl.csv

Corrélation de rang entre chaque paire d'indicateurs de santé mentale, de recours aux soins et de vulnérabilité, par département, avec intervalle de confiance, correction de Benjamini-Hochberg et valeur sans l'Île-de-France. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `variable_a` | Identifiant de l'indicateur comparé (voir les indicateurs de contexte). |
| `variable_b` | Identifiant de l'indicateur comparé (voir les indicateurs de contexte). |
| `departements` | Nombre de départements comparés. |
| `rho` | Corrélation de rang de Spearman. |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `rho_sans_ile_de_france` | Corrélation de rang sans les huit départements d'Île-de-France. |
| `q_bh` | q-valeur après correction de Benjamini-Hochberg. |

## croisements_odbl.csv

Croisements départementaux entre une mesure de l'offre et un indicateur du profil ou du besoin, corrélation de rang brute et à densité de population égale, avec intervalles de confiance par bootstrap. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `theme` | Thème du croisement. |
| `mesure` | Résultat recalculé (nombre, distance médiane, part à plus de 20 km, classement des départements, éloignement selon le niveau de vie). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `departements` | Nombre de départements comparés. |
| `rho` | Corrélation de rang de Spearman. |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `rho_partiel_densite` | Corrélation partielle de rang à densité de population égale (effet ville retiré). |
| `ic95_bas_partiel` | Borne de l'intervalle de confiance à 95 % de la corrélation partielle. |
| `ic95_haut_partiel` | Borne de l'intervalle de confiance à 95 % de la corrélation partielle. |

## declares_etablissements.csv

Professionnels déclarés au répertoire dans un établissement dont plusieurs structures de la même commune partagent le numéro FINESS, une ligne par établissement. Cet effectif n'est attribué à aucune de ces structures.

| Colonne | Description |
|---|---|
| `finess` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `commune` | Commune de l'établissement. |
| `nom_commune` | Nom de la commune. |
| `declares_psychiatre` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_pedopsychiatre` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_q_psychiatrie_enfant` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_psychologue` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_infirmier` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_orthophoniste` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_psychomotricien` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_ergotherapeute` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_medecin_generaliste` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_pediatre` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_geriatre` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_sage_femme` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_masseur_kinesitherapeute` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_urgentiste` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `structures_partageant` | Nombre de structures de la commune, tous types confondus, qui partagent ce numéro FINESS. |

## decomposition_theil.csv

Décomposition de l'indice de Theil entre et dans les départements, et entre et dans les classes de densité.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `groupes` | Découpage utilisé pour la décomposition (départements ou classes de densité). |
| `theil` | Indice de Theil de la répartition rapportée à la population. |
| `entre` | Part de l'indice de Theil entre les groupes ou dans les groupes. |
| `dans` | Part de l'indice de Theil entre les groupes ou dans les groupes. |
| `part_entre` | Part de l'inégalité qui tient aux écarts entre groupes. |

## diplomes_psychologues.csv

Diplômes déclarés par les psychologues.

| Colonne | Description |
|---|---|
| `diplome` | Libellé du diplôme. |
| `psychologues` | Nombre de psychologues. |

## distances_lieux_classes_densite.csv

Distance des habitants à la structure de soins la plus proche selon le type de territoire (classes de densité des intercommunalités), avec le test de l'écart entre classes.

| Colonne | Description |
|---|---|
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `classe` | Classe de densité de population ou groupe de la typologie. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `distance_mediane_km` | Distance médiane des habitants à la structure la plus proche, en km, à vol d'oiseau, cherchée sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucune. |
| `part_plus_20_km` | Part des habitants à plus de 20 ou 30 km de la structure la plus proche. |
| `kruskal_H` | Statistique du test de Kruskal-Wallis. |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `epsilon2` | Taille d'effet epsilon² du test de Kruskal-Wallis. |
| `intercommunalites` | Nombre d'intercommunalités comparées. |
| `q_bh` | q-valeur après correction de Benjamini-Hochberg. |
| `libelle_type` | Libellé du type de structure de soins. |

## distances_lieux_communes.csv

Distance à vol d'oiseau du centre de chaque commune à la structure de soins la plus proche de chaque type recensé presque partout.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `dep` | Code du département. |
| `dist_lieu_accompagnement_handicap` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_addicto_hosp` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_alzheimer` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_caarud` | Distance à la structure la plus proche, CAARUD (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_camsp` | Distance à la structure la plus proche, CAMSP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cattp` | Distance à la structure la plus proche, CATTP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_centre_sante` | Distance à la structure la plus proche, centres de santé (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmp` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_cmp_adultes` | Distance à la structure la plus proche, CMP pour adultes (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmp_enfants` | Distance à la structure la plus proche, CMP pour enfants et adolescents (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_cmpp` | Distance à la structure la plus proche, CMPP (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_csapa` | Distance à la structure la plus proche, CSAPA (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_depistage` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_dialyse` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_ehpad` | Distance à la structure la plus proche, EHPAD (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_esat` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_foyers_handicap` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_had` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_hc_psy_adultes` | Distance à la structure la plus proche, hospitalisation complète en psychiatrie (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hc_psy_enfants` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_hdj_psy_adultes` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (adultes) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_hdj_psy_enfants` | Distance à la structure la plus proche, hôpitaux de jour en psychiatrie (enfants et adolescents) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_ime` | Distance à la structure la plus proche, instituts médico-éducatifs (IME) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_itep` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_mas_fam` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_maternite` | Distance à la structure la plus proche, maternités (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_msp` | Distance à la structure la plus proche, maisons de santé pluriprofessionnelles (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_pmi` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_polyhandicap_enfants` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_precarite` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_residence_autonomie` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_sessad` | Distance à la structure la plus proche, services d'éducation spéciale et de soins à domicile (SESSAD) (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_smr` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_ssiad` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |
| `dist_lieu_urgences` | Distance à la structure la plus proche, services d'urgences (km), source ANS, offres de santé (ROR) et FINESS, réunis sans double compte. Publié pour les intercommunalités, départements, régions, vide aux autres niveaux. |
| `dist_lieu_usld` | Distance médiane des habitants à la structure la plus proche de ce type, en km, à vol d'oiseau. |

## distances_lieux_dep.csv

Distance à vol d'oiseau des habitants à la structure de soins la plus proche de chaque type, par département.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `distance_mediane_km` | Distance médiane des habitants à la structure la plus proche, en km, à vol d'oiseau, cherchée sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucune. |
| `part_plus_20_km` | Part des habitants à plus de 20 ou 30 km de la structure la plus proche. |
| `part_plus_30_km` | Part des habitants à plus de 20 ou 30 km de la structure la plus proche. |
| `libelle_type` | Libellé du type de structure de soins. |
| `nom` | Nom du territoire. |
| `recensement_complet` | Vrai quand ce type de structure est recensé dans au moins 90 % des départements. Faux, les distances sont trop longues, la structure existant souvent sans être inscrite sous ce type dans FINESS ou le ROR. |

## distances_lieux_epci.csv

Distance à vol d'oiseau des habitants à la structure de soins la plus proche de chaque type, par intercommunalité.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `distance_mediane_km` | Distance médiane des habitants à la structure la plus proche, en km, à vol d'oiseau, cherchée sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucune. |
| `part_plus_20_km` | Part des habitants à plus de 20 ou 30 km de la structure la plus proche. |
| `part_plus_30_km` | Part des habitants à plus de 20 ou 30 km de la structure la plus proche. |
| `libelle_type` | Libellé du type de structure de soins. |
| `nom` | Nom du territoire. |
| `recensement_complet` | Vrai quand ce type de structure est recensé dans au moins 90 % des départements. Faux, les distances sont trop longues, la structure existant souvent sans être inscrite sous ce type dans FINESS ou le ROR. |

## distances_lieux_france.csv

Distance à vol d'oiseau des habitants à la structure de soins la plus proche de chaque type, France entière.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `distance_mediane_km` | Distance médiane des habitants à la structure la plus proche, en km, à vol d'oiseau, cherchée sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucune. |
| `part_plus_20_km` | Part des habitants à plus de 20 ou 30 km de la structure la plus proche. |
| `part_plus_30_km` | Part des habitants à plus de 20 ou 30 km de la structure la plus proche. |
| `libelle_type` | Libellé du type de structure de soins. |
| `recensement_complet` | Vrai quand ce type de structure est recensé dans au moins 90 % des départements. Faux, les distances sont trop longues, la structure existant souvent sans être inscrite sous ce type dans FINESS ou le ROR. |

## distances_lieux_reg.csv

Distance à vol d'oiseau des habitants à la structure de soins la plus proche de chaque type, par région.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `distance_mediane_km` | Distance médiane des habitants à la structure la plus proche, en km, à vol d'oiseau, cherchée sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucune. |
| `part_plus_20_km` | Part des habitants à plus de 20 ou 30 km de la structure la plus proche. |
| `part_plus_30_km` | Part des habitants à plus de 20 ou 30 km de la structure la plus proche. |
| `libelle_type` | Libellé du type de structure de soins. |
| `nom` | Nom du territoire. |
| `recensement_complet` | Vrai quand ce type de structure est recensé dans au moins 90 % des départements. Faux, les distances sont trop longues, la structure existant souvent sans être inscrite sous ce type dans FINESS ou le ROR. |

## double_eloignement.csv

Part des habitants qui vivent dans une intercommunalité sans professionnel déclaré du champ et à plus de 20 km à vol d'oiseau d'une structure du même champ, France, régions et départements.

| Colonne | Description |
|---|---|
| `champ` | Champ du double éloignement (adultes, enfants). |
| `libelle` | Libellé de la profession. |
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `part_sans_professionnel` | Part des habitants dont l'intercommunalité ne compte aucun professionnel déclaré du champ. |
| `part_loin_structure` | Part des habitants à plus de 20 km de la structure du champ la plus proche. |
| `part_double_eloignement` | Part des habitants dans les deux situations à la fois. |
| `habitants_double_eloignement` | Nombre d'habitants dans les deux situations à la fois. |
| `nom` | Nom du territoire. |

## ecarts_attendu.csv

Effectif observé et attendu par intercommunalité et profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `effectif` | Effectif (personnes distinctes, somme sur les territoires pour inegalites.csv). |
| `effectif_attendu` | Effectif attendu compte tenu du profil sociodémographique (régression de Poisson). Ce n'est pas une mesure du besoin. |
| `pop` | Population du territoire (référentiel Etalab, population municipale). |
| `observe` | Densité observée pour 10 000 habitants. |
| `attendu` | Densité attendue pour 10 000 habitants. |
| `rapport` | Effectif observé divisé par l'effectif attendu (1 conforme au profil, 0,5 deux fois moins). |
| `manque` | Effectif attendu moins effectif observé. |
| `effectif_attendu_nb` | Effectif attendu selon le modèle binomial négatif, qui tolère une variabilité plus forte que le modèle de Poisson. |
| `rapport_nb` | Effectif observé rapporté à l'effectif attendu du modèle binomial négatif. |

## effectifs_com_all.csv

Effectifs et densités par commune, tous modes d'exercice. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_com_lib.csv

Effectifs et densités par commune, exercice libéral. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_com_sal.csv

Effectifs et densités par commune, exercice salarié. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_dep_all.csv

Effectifs et densités par département, tous modes d'exercice. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_dep_lib.csv

Effectifs et densités par département, exercice libéral. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_dep_sal.csv

Effectifs et densités par département, exercice salarié. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_epci_all.csv

Effectifs et densités par intercommunalité, tous modes d'exercice. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_epci_lib.csv

Effectifs et densités par intercommunalité, exercice libéral. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_epci_sal.csv

Effectifs et densités par intercommunalité, exercice salarié. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_france.csv

Effectifs nationaux par profession et mode d'exercice, en personnes distinctes, activités sans lieu d'exercice comprises.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `mode` | Mode d'exercice, all (tous), lib (libéral), sal (salarié), aut (autre, bénévole). |
| `n` | Nombre de personnes distinctes. |
| `libelle` | Libellé de la profession. |

## effectifs_reg_all.csv

Effectifs et densités par région, tous modes d'exercice. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_reg_lib.csv

Effectifs et densités par région, exercice libéral. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## effectifs_reg_sal.csv

Effectifs et densités par région, exercice salarié. Une ligne par territoire, une paire de colonnes par profession.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## entonnoir.csv

Position de chaque territoire dans le diagramme en entonnoir.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `effectif` | Effectif (personnes distinctes, somme sur les territoires pour inegalites.csv). |
| `effectif_au_taux_national` | Effectif qu'aurait le territoire avec la densité nationale. |
| `statut` | Concorde (écart d'au plus 20 % ou d'un CMP), moins ici, plus ici, ou établissement absent de la SAE. |

## entonnoir_limites.csv

Limites de l'entonnoir selon la population (pour tracer le graphique).

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `bas_95` | Limite de l'entonnoir en densité pour 10 000 habitants (95 % ou 99,8 %). |
| `haut_95` | Limite de l'entonnoir en densité pour 10 000 habitants (95 % ou 99,8 %). |
| `bas_998` | Limite de l'entonnoir en densité pour 10 000 habitants (95 % ou 99,8 %). |
| `haut_998` | Limite de l'entonnoir en densité pour 10 000 habitants (95 % ou 99,8 %). |

## entonnoir_resume.csv

Part des territoires et des habitants hors des limites de l'entonnoir.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `densite_nationale` | Somme des effectifs des territoires du niveau rapportée à la population, pour 10 000 habitants. Un professionnel qui exerce dans plusieurs territoires y compte une fois par territoire, c'est l'ensemble des territoires, calculé comme eux, et non la densité de la France, dont l'effectif (chaque personne une fois) est dans effectifs_france.csv. |
| `part_hors_95` | Part des territoires hors des limites à 95 %. |
| `part_nettement_en_dessous` | Part des territoires sous la limite basse à 99,8 %. |
| `part_population_nettement_en_dessous` | Part des habitants vivant dans ces territoires. |

## escalier_distance_lieux.csv

Distance des habitants à la structure de soins la plus proche selon le niveau de vie de leur intercommunalité, par dixième de la population.

| Colonne | Description |
|---|---|
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `decile` | Dixième de la population, de 1 (territoires les plus modestes) à 10 (les plus aisés). |
| `niveau_de_vie_min` | Niveau de vie médian le plus bas ou le plus haut des territoires de la tranche (€). |
| `niveau_de_vie_max` | Niveau de vie médian le plus bas ou le plus haut des territoires de la tranche (€). |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `distance_mediane_km` | Distance médiane des habitants à la structure la plus proche, en km, à vol d'oiseau, cherchée sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucune. |
| `part_plus_20_km` | Part des habitants à plus de 20 ou 30 km de la structure la plus proche. |
| `libelle_type` | Libellé du type de structure de soins. |

## escalier_social.csv

Densité de professionnels par dixième de la population, territoires classés par niveau de vie croissant.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `decile` | Dixième de la population, de 1 (territoires les plus modestes) à 10 (les plus aisés). |
| `niveau_de_vie_min` | Niveau de vie médian le plus bas ou le plus haut des territoires de la tranche (€). |
| `niveau_de_vie_max` | Niveau de vie médian le plus bas ou le plus haut des territoires de la tranche (€). |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `effectif` | Effectif (personnes distinctes, somme sur les territoires pour inegalites.csv). |
| `densite` | Professionnels pour 10 000 habitants. |

## etablissements_verifies.csv

Établissements dont les structures ont été reprises une à une sur leurs propres sources (liste vérifiée).

| Colonne | Description |
|---|---|
| `ej` | Numéro FINESS de l'entité juridique (l'hôpital ou l'association gestionnaire). |
| `etablissement` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `departement` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `types` | Types de structures vérifiés pour cet établissement. |
| `date` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `sources` | Sources consultées. |
| `remarque` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `structures_etablissement` | Structures confirmées par l'établissement. |
| `structures_source_publique` | Structures confirmées par une autre source publique. |
| `structures_bases` | Structures seulement inscrites dans FINESS ou le ROR. |
| `raison_reverification` | Pourquoi l'établissement est à revérifier (inscriptions de FINESS ou du ROR modifiées, vérification de plus d'un an, structure de sa liste fermée depuis dans FINESS), vide sinon. |
| `a_reverifier` | Vrai quand les inscriptions des bases ont changé depuis la vérification, qu'elle a plus d'un an, ou qu'une structure de sa liste a été fermée depuis dans FINESS. |

## evolution_explorer.csv

Effectif et population de chaque année depuis 2016, par département, pour toutes les séries de démographie de la DREES (colonne source, RPPS, ADELI jusqu'en 2024, SNDS pour les infirmiers libéraux, base Tous salariés pour les infirmiers salariés), données des trajectoires de la page Explorer.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `libelle` | Libellé de la profession. |
| `source` | Page du jeu de données chez le producteur. |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `annee` | Année des données (pour le fichier des diplômes, année d'obtention, non disponible dans l'extraction publique actuelle). |
| `effectif` | Effectif (personnes distinctes, somme sur les territoires pour inegalites.csv). |
| `population` | Population du territoire (référentiel Etalab, population municipale). |

## evolution_offre.csv

Effectif et densité de chaque année, par profession, pour la France, les régions et les départements, d'après les séries de démographie de la DREES (un professionnel compté une fois, dans le département de son activité principale) et les estimations de population de l'INSEE au 1er janvier.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `libelle` | Libellé de la profession. |
| `annee` | Année des données (pour le fichier des diplômes, année d'obtention, non disponible dans l'extraction publique actuelle). |
| `effectif` | Effectif (personnes distinctes, somme sur les territoires pour inegalites.csv). |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `densite` | Professionnels pour 10 000 habitants. |

## evolution_offre_resume.csv

Évolution de la densité entre la première et la dernière année de la période, par profession et territoire.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `libelle` | Libellé de la profession. |
| `annee_debut` | Première et dernière année de la période d'évolution. |
| `annee_fin` | Première et dernière année de la période d'évolution. |
| `effectif_debut` | Effectif de la profession au 1er janvier de la première et de la dernière année (DREES). |
| `effectif_fin` | Effectif de la profession au 1er janvier de la première et de la dernière année (DREES). |
| `densite_<profession>` | Professionnels pour 10 000 habitants au 1er janvier de la première et de la dernière année. |
| `evolution_densite` | Variation relative de la densité entre les deux années (0,10 pour une hausse de 10 %). |

## exercice_multisites.csv

Part des professionnels qui exercent dans plusieurs communes ou intercommunalités.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `personnes` | Personnes distinctes. |
| `plusieurs_communes` | Personnes exerçant dans au moins deux communes ou intercommunalités. |
| `plusieurs_epci` | Personnes exerçant dans au moins deux communes ou intercommunalités. |
| `communes_moyennes` | Nombre moyen de communes d'exercice par personne. |
| `part_plusieurs_communes` | Part de ces personnes. |
| `part_plusieurs_epci` | Part de ces personnes. |

## exercice_structures.csv

Professionnels qui déclarent exercer dans une structure de santé mentale enregistrée sous son propre numéro FINESS (CMP, CATTP, CMPP, CAMSP, CSAPA, CAARUD), par type, en France, par région et par département, en personnes distinctes.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `libelle_type` | Libellé du type de structure de soins. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `personnes` | Personnes distinctes. |

## feminisation.csv

Part de femmes (civilité déclarée) par profession, en France et par département.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `personnes` | Personnes distinctes. |
| `femmes` | Nombre de femmes (civilité déclarée « Madame »). |
| `mode` | Mode d'exercice, all (tous), lib (libéral), sal (salarié), aut (autre, bénévole). |
| `part_femmes` | Part de femmes. |

## gwr_coefficients.csv

Régression géographiquement pondérée, coefficients locaux par intercommunalité de l'Hexagone (psychologues, psychiatres, généralistes).

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `coef_niveau_de_vie` | Coefficient local du niveau de vie médian, en écarts-types de la densité (en logarithme) pour un écart-type de niveau de vie, à densité de population égale. |
| `erreur_std` | Erreur standard robuste. |
| `t` | Statistique de test. |
| `net` | Vrai si le coefficient local dépasse le seuil ajusté des tests locaux (da Silva et Fotheringham 2016). |
| `coef_densite_pop` | Coefficient local de la densité de population (en logarithme). |
| `r2_local` | Part des écarts expliquée par la régression locale, pondérée par les poids des voisines. |

## gwr_resume.csv

Régression géographiquement pondérée, résumé par profession (voisines, AICc, répartition des coefficients locaux, test de variation spatiale).

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `intercommunalites` | Nombre d'intercommunalités comparées. |
| `voisines` | Nombre d'intercommunalités voisines retenues par le noyau, choisi par le critère AICc. |
| `parametres_effectifs` | Nombre effectif de paramètres de la régression géographiquement pondérée. |
| `aicc_gwr` | Critère AICc de la régression pondérée et de la régression ordinaire, plus bas est meilleur. |
| `aicc_ols` | Critère AICc de la régression pondérée et de la régression ordinaire, plus bas est meilleur. |
| `r2_gwr` | Part des écarts entre intercommunalités résumée par la régression pondérée. |
| `coef_global_niveau_de_vie` | Coefficient du niveau de vie dans la régression ordinaire sur toute l'Hexagone. |
| `coef_local_q1` | Premier quartile, médiane et troisième quartile des coefficients locaux. |
| `coef_local_mediane` | Premier quartile, médiane et troisième quartile des coefficients locaux. |
| `coef_local_q3` | Premier quartile, médiane et troisième quartile des coefficients locaux. |
| `part_positif_net` | Part des intercommunalités où le coefficient local est positif (négatif) et net. |
| `part_negatif_net` | Part des intercommunalités où le coefficient local est positif (négatif) et net. |
| `seuil_t_ajuste` | Seuil des tests locaux, ajusté au nombre effectif de paramètres. |
| `p_variation_niveau_de_vie` | Test de variation spatiale du coefficient, par 49 permutations des positions. Faible, le lien change vraiment d'une région à l'autre. |
| `p_variation_densite_pop` | Test de variation spatiale du coefficient, par 49 permutations des positions. Faible, le lien change vraiment d'une région à l'autre. |

## honoraires_odbl.csv

Honoraires des libéraux et dépassements réellement facturés, par spécialité, en France, par région et par département (Assurance Maladie, dernière année). Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `annee` | Année des données (pour le fichier des diplômes, année d'obtention, non disponible dans l'extraction publique actuelle). |
| `profession_sante` | Spécialité, libellé de l'Assurance Maladie. |
| `hono_sans_depassement_totaux` | Honoraires sans dépassement des libéraux de la spécialité, en euros. |
| `depassements_totaux` | Dépassements d'honoraires facturés par les libéraux de la spécialité, en euros, vide sous secret statistique. |
| `depassements_moyens` | Dépassements moyens par libéral de la spécialité, en euros, vide sous secret statistique. |
| `taux_depassement_s2` | Dépassements des libéraux de secteur 2 en part de leurs honoraires sans dépassement, tel que publié, vide sous secret statistique ou sans libéral de secteur 2. |
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `trop_peu` | Description manquante, à compléter dans pipeline/dictionnaire.py. |

## inegalites.csv

Indicateurs d'inégalité de répartition par profession, niveau et mode.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `mode` | Mode d'exercice, all (tous), lib (libéral), sal (salarié), aut (autre, bénévole). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `effectif` | Effectif (personnes distinctes, somme sur les territoires pour inegalites.csv). |
| `densite_nationale` | Somme des effectifs des territoires du niveau rapportée à la population, pour 10 000 habitants. Un professionnel qui exerce dans plusieurs territoires y compte une fois par territoire, c'est l'ensemble des territoires, calculé comme eux, et non la densité de la France, dont l'effectif (chaque personne une fois) est dans effectifs_france.csv. |
| `moyenne` | Statistique de la densité pour 10 000 habitants entre territoires. |
| `mediane` | Statistique de la densité pour 10 000 habitants entre territoires. |
| `p10` | Statistique de la densité pour 10 000 habitants entre territoires. |
| `p90` | Statistique de la densité pour 10 000 habitants entre territoires. |
| `rapport_p90_p10` | Rapport entre le 9e et le 1er décile des densités. |
| `gini` | Indice de Gini de la répartition rapportée à la population (0 égalité, 1 concentration totale). |
| `theil` | Indice de Theil de la répartition rapportée à la population. |
| `territoires_sans_professionnel` | Nombre de territoires sans aucun professionnel. |
| `part_population_sans_professionnel` | Part de la population vivant dans un territoire sans professionnel. |

## inscrits_sans_activite.csv

Personnes inscrites au RPPS (hors étudiants) et personnes ayant au moins une activité déclarée, par profession. Sans activité déclarée ne veut pas dire sans exercice, le fichier ne dit rien de ces inscrits.

| Colonne | Description |
|---|---|
| `libelle_rpps` | Libellé de la profession dans le RPPS. |
| `inscrits` | Personnes inscrites au RPPS pour cette profession, hors étudiants. |
| `avec_activite` | Personnes ayant au moins une activité déclarée (effectif national publié ici). |
| `sans_activite_declaree` | Personnes inscrites sans aucune activité déclarée. Le fichier ne donne ni lieu, ni âge, ni date pour elles, on ne sait donc pas si elles exercent. |
| `part_sans_activite_declaree` | Part des inscrits sans activité déclarée. |

## libelles.csv

Table de correspondance entre libellés officiels et libellés d'affichage.

| Colonne | Description |
|---|---|
| `source` | Nomenclature d'origine. |
| `code` | Code dans la nomenclature, s'il existe. |
| `libelle_origine` | Libellé officiel de la nomenclature. |
| `libelle_affichage` | Libellé affiché au lecteur. |
| `statut` | Statut de validation. |
| `remarque` | Justification ou point de vigilance. |

## liens_entre_intercommunalites.csv

Nombre de professionnels exerçant à la fois dans deux intercommunalités (au moins 3).

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `epci_a` | Code des deux intercommunalités reliées. |
| `epci_b` | Code des deux intercommunalités reliées. |
| `n` | Nombre de personnes distinctes. |
| `nom_a` | Nom des deux intercommunalités reliées. |
| `nom_b` | Nom des deux intercommunalités reliées. |

## lieux_couverture.csv

Part des départements où chaque type de lieu est recensé. Sous 90 %, le type est listé mais pas comparé entre territoires.

| Colonne | Description |
|---|---|
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `part_departements` | Part des départements (Mayotte écartée) où au moins une structure de ce type est recensée. |
| `complet` | Vrai quand le type est recensé dans au moins 90 % des départements et comparé entre territoires. |
| `libelle_type` | Libellé du type de structure de soins. |

## lieux_references.csv

Nombre de lieux rapproché des chiffres publiés par la DREES.

| Colonne | Description |
|---|---|
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `lieux` | Lieux recensés ici, chiffre publié, sa date, ce qu'il compte, écart relatif. |
| `reference` | Lieux recensés ici, chiffre publié, sa date, ce qu'il compte, écart relatif. |
| `date_reference` | Lieux recensés ici, chiffre publié, sa date, ce qu'il compte, écart relatif. |
| `objet` | Lieux recensés ici, chiffre publié, sa date, ce qu'il compte, écart relatif. |
| `ecart` | CMP recensés ici moins CMP déclarés à la SAE. |
| `source` | Page du jeu de données chez le producteur. |
| `adresse` | Adresse de la structure (voie), quand elle est connue. |

## lieux_soins.csv

Structures de soins réunies de FINESS et du Répertoire opérationnel des ressources (ROR), sans double compte. Une ligne par structure et par type, avec son emplacement, sa provenance et les professionnels déclarés sous son numéro FINESS quand elle est seule à le porter dans sa commune.

| Colonne | Description |
|---|---|
| `id_structure` | Clé persistante de la structure, la même d'une version à l'autre même quand son numéro FINESS, son nom ou son inscription au ROR changent, jamais réutilisée (règle dans pipeline/cles_structures.py). |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `libelle_type` | Libellé du type de structure de soins. |
| `famille` | Famille, « Santé mentale » ou « Santé » (dans les fichiers de la typologie, sm, sante ou tout). |
| `groupe` | Groupe du type de lieu ou de la profession. |
| `nom` | Nom du territoire. |
| `unite_ror` | Nom de l'unité dans le ROR (vide pour une structure présente dans FINESS seul). |
| `secteur` | Code du secteur de psychiatrie quand le nom de la structure le cite (93G16, 31I01, G pour la psychiatrie générale, I pour la psychiatrie infanto-juvénile, Z pour un intersecteur), vide sinon. Il ne dit pas quelles communes le secteur dessert. |
| `finess` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `finess_rapproche` | Numéro FINESS d'un CMP de FINESS rapproché de la structure du ROR par l'entité juridique et la commune. |
| `finess_absorbes` | Autres numéros FINESS du même lieu, enregistré plusieurs fois (sous deux entités juridiques ou deux catégories) et compté une seule fois. |
| `entite_juridique` | Numéro FINESS de l'entité juridique gestionnaire. |
| `commune` | Commune de l'établissement. |
| `commune_inscription` | Commune d'inscription de la structure dans FINESS ou le ROR, quand son adresse se trouve dans une commune voisine du même code postal, où elle est comptée (règle du 29 octobre 2026). Vide sinon. |
| `nom_commune` | Nom de la commune. |
| `epci` | Code SIREN de l'intercommunalité. |
| `dep` | Code du département. |
| `reg` | Code de la région. |
| `adresse` | Adresse de la structure (voie), quand elle est connue. |
| `latitude` | Coordonnées de la structure, en degrés (WGS 84). |
| `longitude` | Coordonnées de la structure, en degrés (WGS 84). |
| `emplacement` | Précision de l'emplacement, coordonnées de FINESS, du ROR, adresse géocodée (numéro, rue ou lieu-dit), établissement de rattachement ou centre de la commune. |
| `provenance` | FINESS et ROR, FINESS seul ou ROR seul. |
| `categories_ror` | Codes des catégories du ROR des unités réunies dans le lieu (nomenclature TRE_R244 de l'ANS). |
| `categorie_finess` | Code de catégorie FINESS de l'établissement, quand le lieu y est présent. |
| `age_min` | Âge minimal ou maximal des patients déclaré dans le ROR, en années. |
| `age_max` | Âge minimal ou maximal des patients déclaré dans le ROR, en années. |
| `lits_ror` | Lits déclarés dans le ROR pour les unités de la structure. |
| `unites_ror` | Unités déclarées comme CMP dans le ROR, avant leur réunion en lieux (plusieurs unités d'un même CMP, ou des CMP déclarés à l'adresse de leur hôpital, ne font qu'une structure). |
| `verification` | Statut de la structure dans la liste vérifiée (confirmée par l'établissement, par une autre source publique, ou seulement inscrite dans les bases), vide hors liste vérifiée. |
| `source_verification` | Source qui confirme la structure. |
| `adresse_source_verification` | Adresse de la page de cette source. |
| `date_verification` | Date de la vérification. |
| `source_adresse_verifiee` | Page de l'établissement ou autre source publique où l'adresse de la structure a été lue, quand FINESS et le ROR ne la donnaient pas utilisable (contenus/adresses_verifiees.csv). |
| `date_adresse_verifiee` | Date de lecture de cette source. |
| `classe_confirmation` | Classe de confirmation montrée au lecteur, confirmée (nommée par une source indépendante de FINESS et du ROR), recoupée par la statistique des hôpitaux (SAE, nombre de CATTP de l'établissement ou places d'hôpital de jour du site, l'adresse n'est pas confirmée) ou à vérifier (inscrite dans FINESS ou le ROR seulement). Vide quand le niveau n'est pas établi pour ce type. Détail par source dans la colonne confirmation. |
| `confirmation` | Niveau de confirmation de la structure (vérifiée sur les sources de l'établissement, sur une autre source publique, confirmée par la HAS (certification de l'hôpital ou évaluation de la structure médico-sociale) ou par Sirene, concordante avec la SAE (nombre de CATTP de son établissement, places d'hôpital de jour de son site), examinée à la main et maintenue, ou à vérifier). Vide pour les types qui ne sont pas encore confrontés à ces listes. |
| `site_certification_has` | Vrai quand un numéro FINESS de la structure est un site de la dernière certification HAS de son établissement dont le nom désigne son type, ou une structure médico-sociale évaluée par la HAS sous la catégorie de son type. |
| `siret_sirene` | Numéro SIRET de l'établissement Sirene correspondant. |
| `enseigne_sirene` | Enseigne de cet établissement dans Sirene. |
| `adresse_sirene` | Adresse de cet établissement dans Sirene. |
| `role` | Pour les CMPP, CAMSP, CSAPA et CAARUD, structure principale, antenne (établissement rattaché à un principal par la relation de budget de FINESS, ou désigné comme antenne par son nom) ou site supplémentaire (lieu du ROR au numéro d'une autre structure). En addictologie aussi consultation jeunes consommateurs, hébergement, milieu pénitentiaire, ou équipe de liaison sans lieu propre. Chaque ligne est un site d'accueil, compté pour les distances et la carte, sauf le milieu pénitentiaire et les équipes de liaison. |
| `verdict` | Résultat de la vérification à la main d'une structure inscrite seulement dans les bases ou absente de la liste de son établissement (existe, ou pas_un_cmp pour une unité rangée dans son type réel). Vide sans vérification à la main. |
| `examen` | Constat et source de cette vérification à la main (site de l'établissement, Sirene, fiche Santé.fr, appel téléphonique...). |
| `declares_psychiatre` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_pedopsychiatre` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_q_psychiatrie_enfant` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_psychologue` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_infirmier` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_orthophoniste` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_psychomotricien` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_ergotherapeute` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_medecin_generaliste` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_pediatre` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_geriatre` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_sage_femme` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_masseur_kinesitherapeute` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_urgentiste` | Personnes déclarant au répertoire une activité sous le numéro FINESS de la structure et dans sa commune, pour cette profession, quand la structure est seule sous ce numéro dans la commune. Vide pour une structure sans numéro FINESS propre, et pour une structure qui partage son numéro avec d'autres (voir declares_partage_par), l'effectif étant alors celui de l'établissement. Une personne déclarée dans deux structures compte dans chacune, ces effectifs ne s'additionnent pas. |
| `declares_partage_par` | Nombre de structures de la commune, tous types confondus, qui partagent le numéro FINESS de celle-ci. Le répertoire rattache une activité à l'établissement, pas à la structure, l'effectif de l'établissement n'est alors attribué à aucune d'elles et figure une seule fois dans declares_etablissements.csv. Vide quand la structure est seule sous son numéro. |

## lieux_soins_dep.csv

Nombre de structures de soins de chaque type par département, et pour 100 000 personnes de leur public (enfants, personnes âgées) ou pour 100 000 habitants, mêmes taux que le site, non publiés là où les bases inscrivent moins de la moitié des structures de la SAE.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de structures de ce type dans le territoire. |
| `pour_100000_lieu_accompagnement_handicap` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_addicto_hosp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_alzheimer` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_bapu` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_caarud` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_camsp` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cancerologie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cardiologie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cattp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_centre_sante` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_chirurgie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmp_adultes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmp_enfants` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmpp` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_consult_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cpts` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_crise_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_csapa` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_depistage` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_dialyse` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_douleur` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_ehpad` | Nombre de structures de ce type pour 100 000 personnes de 80 ans et plus, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_esat` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_foyers_handicap` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_geriatrie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_had` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hc_psy_adultes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hc_psy_enfants` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hdj_psy_adultes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hdj_psy_enfants` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_ime` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_itep` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_mas_fam` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_maternite` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_mda` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_medecine` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_mobile_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_msp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_neonatalogie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_neurologie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_pediatrie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_perinatal_proximite` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_pmi` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_polyhandicap_enfants` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_precarite` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_psychotrauma` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_reanimation` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_rehab_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_residence_autonomie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_sante_sexuelle` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_sessad` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_smr` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_smur` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_soins_non_programmes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_soins_palliatifs` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_ssiad` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_tnd` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_urgences` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_usld` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `taux_non_publies` | Types dont le taux n'est pas publié dans ce territoire, avec la raison : moins de la moitié des structures que les établissements déclarent à la SAE sont inscrites dans FINESS et le ROR. Les nombres de structures inscrites restent publiés. |

## lieux_soins_epci.csv

Nombre de structures de soins de chaque type par intercommunalité, et pour 100 000 personnes de leur public (enfants, personnes âgées) ou pour 100 000 habitants, mêmes taux que le site, non publiés là où les bases inscrivent moins de la moitié des structures de la SAE.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de structures de ce type dans le territoire. |
| `pour_100000_lieu_accompagnement_handicap` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_addicto_hosp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_alzheimer` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_bapu` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_caarud` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_camsp` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cancerologie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cardiologie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cattp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_centre_sante` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_chirurgie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmp_adultes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmp_enfants` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmpp` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_consult_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cpts` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_crise_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_csapa` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_depistage` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_dialyse` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_douleur` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_ehpad` | Nombre de structures de ce type pour 100 000 personnes de 80 ans et plus, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_esat` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_foyers_handicap` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_geriatrie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_had` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hc_psy_adultes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hc_psy_enfants` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hdj_psy_adultes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hdj_psy_enfants` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_ime` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_itep` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_mas_fam` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_maternite` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_mda` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_medecine` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_mobile_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_msp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_neonatalogie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_neurologie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_pediatrie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_perinatal_proximite` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_pmi` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_polyhandicap_enfants` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_precarite` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_psychotrauma` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_reanimation` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_rehab_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_residence_autonomie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_sante_sexuelle` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_sessad` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_smr` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_smur` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_soins_non_programmes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_soins_palliatifs` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_ssiad` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_tnd` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_urgences` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_usld` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `taux_non_publies` | Types dont le taux n'est pas publié dans ce territoire, avec la raison : moins de la moitié des structures que les établissements déclarent à la SAE sont inscrites dans FINESS et le ROR. Les nombres de structures inscrites restent publiés. |

## lieux_soins_reg.csv

Nombre de structures de soins de chaque type par région, et pour 100 000 personnes de leur public (enfants, personnes âgées) ou pour 100 000 habitants, mêmes taux que le site, non publiés là où les bases inscrivent moins de la moitié des structures de la SAE.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `n_<profession>` | Nombre de structures de ce type dans le territoire. |
| `pour_100000_lieu_accompagnement_handicap` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_addicto_hosp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_alzheimer` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_bapu` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_caarud` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_camsp` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cancerologie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cardiologie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cattp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_centre_sante` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_chirurgie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmp_adultes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmp_enfants` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cmpp` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_consult_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_cpts` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_crise_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_csapa` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_depistage` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_dialyse` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_douleur` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_ehpad` | Nombre de structures de ce type pour 100 000 personnes de 80 ans et plus, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_esat` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_foyers_handicap` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_geriatrie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_had` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hc_psy_adultes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hc_psy_enfants` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hdj_psy_adultes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_hdj_psy_enfants` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_ime` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_itep` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_mas_fam` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_maternite` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_mda` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_medecine` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_mobile_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_msp` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_neonatalogie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_neurologie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_pediatrie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_perinatal_proximite` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_pmi` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_polyhandicap_enfants` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_precarite` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_psychotrauma` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_reanimation` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_rehab_psy` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_residence_autonomie` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_sante_sexuelle` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_sessad` | Nombre de structures de ce type pour 100 000 enfants de moins de 15 ans, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_smr` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_smur` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_soins_non_programmes` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_soins_palliatifs` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_ssiad` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_tnd` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_urgences` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `pour_100000_lieu_usld` | Nombre de structures de ce type pour 100 000 habitants, même règle que le site. Vide là où les bases inscrivent moins de la moitié des structures que la SAE déclare (colonne taux_non_publies). |
| `taux_non_publies` | Types dont le taux n'est pas publié dans ce territoire, avec la raison : moins de la moitié des structures que les établissements déclarent à la SAE sont inscrites dans FINESS et le ROR. Les nombres de structures inscrites restent publiés. |

## lisa.csv

Zones de désert et de concentration (indice de Moran local) par intercommunalité.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `I` | Indice de Moran local du territoire. |
| `z` | Statistique de test. |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `q` | q-valeur après correction de Benjamini-Hochberg. |
| `zone` | Zone d'éloignement groupé (intercommunalité éloignée entourée d'intercommunalités éloignées), de proximité groupée, intercommunalité éloignée ou proche isolée, ou non significatif après correction. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `densite` | Professionnels pour 10 000 habitants. |

## loi_inverse.csv

Indice de concentration des professionnels entre départements classés de la valeur la plus faible à la plus forte d'un indicateur de besoin. Négatif, l'offre est plus présente là où l'indicateur est faible.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `departements` | Nombre de départements comparés. |
| `indice_concentration` | Indice de concentration selon le niveau de vie (0 égalité, positif en faveur des territoires aisés). |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |

## loi_inverse_odbl.csv

Indice de concentration des professionnels entre départements classés de la valeur la plus faible à la plus forte d'un indicateur de besoin. Négatif, l'offre est plus présente là où l'indicateur est faible. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `departements` | Nombre de départements comparés. |
| `indice_concentration` | Indice de concentration selon le niveau de vie (0 égalité, positif en faveur des territoires aisés). |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |

## lorenz.csv

Points des courbes de Lorenz (21 points par profession et niveau).

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `x` | Coordonnées de la courbe de Lorenz (part cumulée de la population, part cumulée des professionnels). |
| `y` | Coordonnées de la courbe de Lorenz (part cumulée de la population, part cumulée des professionnels). |

## modeles_coefficients.csv

Coefficients des régressions de Poisson (effectif attendu).

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `coef` | Coefficient (logarithme du rapport de taux pour une variable standardisée). |
| `rapport_de_taux` | Rapport de taux, exponentielle du coefficient. |
| `erreur_std` | Erreur standard robuste. |
| `z` | Statistique de test. |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `q_bh` | q-valeur après correction de Benjamini-Hochberg. |

## modeles_qualite.csv

Qualité d'ajustement des régressions de Poisson.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `n` | Nombre de personnes distinctes. |
| `pseudo_r2` | Part de la déviance expliquée par le modèle. |
| `dispersion` | Paramètre de dispersion de Pearson (1 si la variance suit le modèle de Poisson). |
| `alpha_nb` | Paramètre de surdispersion du modèle binomial négatif (0 pour un modèle de Poisson). |
| `aic_poisson` | Critère d'information d'Akaike du modèle (poisson), plus bas pour un meilleur ajustement. |
| `aic_nb` | Critère d'information d'Akaike du modèle (nb), plus bas pour un meilleur ajustement. |
| `rho_rapports_poisson_nb` | Corrélation de rang entre les rapports observé sur attendu des deux modèles. |
| `retrait_communs` | Territoires repérés en retrait par les deux modèles à la fois. |
| `retrait_poisson` | Nombre de territoires dont l'effectif est inférieur à la moitié de l'attendu, avec au moins 5 professionnels attendus, selon le modèle (poisson). |
| `retrait_nb` | Nombre de territoires dont l'effectif est inférieur à la moitié de l'attendu, avec au moins 5 professionnels attendus, selon le modèle (nb). |

## moran_residus.csv

Indice de Moran des écarts à l'attendu des régressions de Poisson.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `moran_residus` | Indice de Moran des écarts à l'attendu. |
| `p_permutation` | p-valeur par permutations. |

## offre_besoin_lisa.csv

Moran local bivarié par département, indicateur de besoin du département et densité moyenne de ses voisins, pour les principales professions de santé mentale, 999 permutations, correction de Benjamini-Hochberg.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `I` | Indice de Moran local du territoire. |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `q` | q-valeur après correction de Benjamini-Hochberg. |
| `zone` | Zone d'éloignement groupé (intercommunalité éloignée entourée d'intercommunalités éloignées), de proximité groupée, intercommunalité éloignée ou proche isolée, ou non significatif après correction. |

## offre_besoin_lisa_odbl.csv

Moran local bivarié par département, indicateur de besoin du département et densité moyenne de ses voisins, pour les principales professions de santé mentale, 999 permutations, correction de Benjamini-Hochberg. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `I` | Indice de Moran local du territoire. |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `q` | q-valeur après correction de Benjamini-Hochberg. |
| `zone` | Zone d'éloignement groupé (intercommunalité éloignée entourée d'intercommunalités éloignées), de proximité groupée, intercommunalité éloignée ou proche isolée, ou non significatif après correction. |

## ombre_urbaine.csv

Intercommunalités peu dotées, distinguées selon leur accessibilité (ombre d'un pôle voisin ou désert).

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `densite` | Professionnels pour 10 000 habitants. |
| `accessibilite` | Accessibilité potentielle à deux étapes, en professionnels pour 10 000 habitants. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `categorie` | Catégorie d'établissement, libellé d'affichage. |

## outre_mer.csv

Densités des départements d'outre-mer comparées à l'Hexagone.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `hexagone` | Densité pour 10 000 habitants dans l'Hexagone. |
| `971` | Densité pour 10 000 habitants dans le département d'outre-mer 971. |
| `972` | Densité pour 10 000 habitants dans le département d'outre-mer 972. |
| `973` | Densité pour 10 000 habitants dans le département d'outre-mer 973. |
| `974` | Densité pour 10 000 habitants dans le département d'outre-mer 974. |
| `976` | Densité pour 10 000 habitants dans le département d'outre-mer 976. |

## parcours_activites.csv

Du répertoire aux densités. Pour chaque profession, personnes inscrites (quand la profession correspond à un libellé du RPPS), personnes avec une activité déclarée, sans lieu d'exercice, avec un lieu, n'exerçant qu'en téléconsultation ou sans soins à la population, et comptées dans les densités des territoires.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `libelle` | Libellé de la profession. |
| `inscrits` | Personnes inscrites au RPPS pour cette profession, hors étudiants. |
| `avec_activite` | Personnes ayant au moins une activité déclarée (effectif national publié ici). |
| `sans_lieu` | Personnes dont aucune activité n'a de commune d'exercice (remplacements, exercice sans site fixe). Comptées dans l'effectif national, pas dans les territoires. |
| `avec_lieu` | Personnes ayant au moins une activité avec une commune d'exercice. |
| `dans_densites` | Personnes ayant au moins une activité localisée de soins ou pour un public particulier, comptées dans la densité d'au moins un territoire. |
| `a_distance_seulement` | Personnes dont aucune activité localisée n'entre dans les densités et qui ont au moins une activité pour une société de téléconsultation (soins à distance, déclarés au siège de la société). Retirées des densités, comptées dans l'effectif national. |
| `sans_soins_seulement` | Personnes dont toutes les activités localisées sont sans soins à la population (sièges, contrôle médical, industrie, recherche...), sans téléconsultation. Retirées des densités, comptées dans l'effectif national. |

## patientele_liberaux_odbl.csv

Description manquante. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `annee` | Année des données (pour le fichier des diplômes, année d'obtention, non disponible dans l'extraction publique actuelle). |
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `file_active` | File active moyenne, nombre moyen de patients différents vus dans l'année par un libéral de la profession dont le cabinet principal est dans le territoire (Assurance Maladie), vide sous secret statistique (moins de 5 libéraux) ou sans libéral. |
| `patients_mt` | Nombre moyen de patients qui ont déclaré le libéral comme médecin traitant (généralistes et pédiatres seulement), vide sinon. |
| `secret` | Vrai si l'effectif est inférieur à 10 et n'est pas publié par l'Assurance Maladie. |
| `aucun` | Vrai quand le territoire ne compte aucun libéral de la profession. |

## population_concernee.csv

Distance à la structure de soins la plus proche, pour tous les habitants et pour le public que sert la structure (mères des enfants nés entre les deux derniers recensements pour la naissance et la petite enfance, moins de 15 ans pour l'enfance), par intercommunalité, département, région et pour la France, hors Mayotte, qui n'a pas de recensement.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `type` | Type de structure (identifiant du site, lieu_maternite, lieu_cmpp...). |
| `public` | Identifiant du public concerné (naissances, moins_15...). |
| `libelle_public` | Nom du public concerné, avec la période pour les naissances. |
| `distance_mediane_km` | Distance médiane des habitants à la structure la plus proche, en km, à vol d'oiseau, cherchée sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucune. |
| `distance_mediane_km_public` | Distance médiane à vol d'oiseau du public concerné à la structure la plus proche, en km, depuis le centre de sa commune (INSEE, communes). |
| `part_plus_30_km` | Part des habitants à plus de 30 km de la structure la plus proche. |
| `part_plus_30_km_public` | Part du public concerné à plus de 30 km de la structure la plus proche. |
| `communes` | Nombre de communes du territoire qui comptent des habitants. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `population_public` | Effectif du public concerné dans le territoire (INSEE, communes ; naissances cumulées sur la période pour les mères). |

## porte_offre.csv

Répartition des professionnels par grand secteur d'exercice selon la densité de population.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `classe` | Classe de densité de population de l'intercommunalité, ou Ensemble. |
| `groupe` | Grand secteur d'exercice (libéral, hôpital public, privé, médico-social...). |
| `n` | Nombre de personnes distinctes. |
| `part` | Part dans la classe de territoires. |

## professions.csv

Liste des professions, qualifications et comptages du périmètre élargi.

| Colonne | Description |
|---|---|
| `id` | Identifiant de la profession. |
| `libelle` | Libellé de la profession. |
| `groupe` | Groupe du type de lieu ou de la profession. |
| `famille` | Famille, « Santé mentale » ou « Santé » (dans les fichiers de la typologie, sm, sante ou tout). |
| `nature` | profession (chaque personne y figure une fois), qualification (qualification complémentaire d'un médecin, non additive) ou perimetre_elargi (salariés d'un établissement psychiatrique, non additif). |
| `base` | Base relue (FINESS, ROR, ou les deux). |

## psychiatrie_hopital.csv

Psychiatrie à l'hôpital d'après la SAE de la DREES (lits, places, CMP, temps plein de psychiatres et psychologues, file active), par département, région et pour la France.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `indicateur` | Identifiant de l'indicateur (voir les indicateurs de contexte). |
| `valeur` | Valeur de l'indicateur, dans l'unité indiquée par le dictionnaire des indicateurs. |
| `nombre` | Nombre brut (lits, places, CMP, équivalents temps plein ou patients selon l'indicateur). |

## public_cible.csv

Densité de certaines professions rapportée à leur public (moins de 15 ans, 65 ans et plus), comparée à la densité par habitant.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `public` | Public de la discipline, adultes (psychiatrie générale) ou enfants (psychiatrie infanto-juvénile). |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |
| `gini_population` | Indice de Gini, rapporté à la population entière ou au public concerné. |
| `gini_public` | Indice de Gini, rapporté à la population entière ou au public concerné. |
| `rho_classements` | Corrélation de rang entre densité par habitant et densité par personne du public. |
| `part_public_sans_professionnel` | Part du public vivant dans un territoire sans ce professionnel. |

## public_cible_territoires.csv

Densité rapportée au public concerné, par territoire.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `public` | Public de la discipline, adultes (psychiatrie générale) ou enfants (psychiatrie infanto-juvénile). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `effectif` | Effectif (personnes distinctes, somme sur les territoires pour inegalites.csv). |
| `population_cible` | Nombre de personnes du public concerné dans le territoire. |
| `densite_<profession>` | Nombre de professionnels <profession> pour 10 000 habitants. |

## quadrants.csv

Position de chaque département selon sa densité de professionnels et un indicateur de besoin, chacun comparé à sa médiane.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `densite` | Professionnels pour 10 000 habitants. |
| `valeur` | Valeur de l'indicateur, dans l'unité indiquée par le dictionnaire des indicateurs. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `quadrant` | besoin+offre- (indicateur au-dessus de la médiane, densité au-dessous), et ainsi de suite. |
| `mediane_densite` | Médiane des départements utilisée comme seuil. |
| `mediane_indicateur` | Médiane des départements utilisée comme seuil. |

## quadrants_odbl.csv

Position de chaque département selon sa densité de professionnels et un indicateur de besoin, chacun comparé à sa médiane. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `densite` | Professionnels pour 10 000 habitants. |
| `valeur` | Valeur de l'indicateur, dans l'unité indiquée par le dictionnaire des indicateurs. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `quadrant` | besoin+offre- (indicateur au-dessus de la médiane, densité au-dessous), et ainsi de suite. |
| `mediane_densite` | Médiane des départements utilisée comme seuil. |
| `mediane_indicateur` | Médiane des départements utilisée comme seuil. |

## regressions_indicateurs.csv

Régression linéaire multiple de quelques indicateurs de santé mentale sur des indicateurs sociaux, départements de l'Hexagone, avec et sans l'Île-de-France, coefficients standardisés.

| Colonne | Description |
|---|---|
| `resultat` | Indicateur étudié par la régression. |
| `champ` | Champ du double éloignement (adultes, enfants). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `coef_standardise` | Variation de l'indicateur étudié, en écarts-types, pour un écart-type de plus de l'indicateur explicatif, les autres restant égaux. |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `erreur_std` | Erreur standard robuste. |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `q_bh` | q-valeur après correction de Benjamini-Hochberg. |
| `vif` | Facteur d'inflation de la variance, au-delà de 5 les indicateurs explicatifs se recouvrent trop. |
| `r2` | Part des écarts entre départements résumée par le modèle (ajustée du nombre d'indicateurs). |
| `r2_ajuste` | Part des écarts entre départements résumée par le modèle (ajustée du nombre d'indicateurs). |
| `departements` | Nombre de départements comparés. |
| `rho_simple` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `depend_de` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `coef_sans_depend_de` | Description manquante, à compléter dans pipeline/dictionnaire.py. |

## relecture_structures.csv

Relecture de FINESS et du ROR, chaque correction apportée avec le nombre de structures concernées.

| Colonne | Description |
|---|---|
| `base` | Base relue (FINESS, ROR, ou les deux). |
| `constat` | Ce qui a été constaté dans la base. |
| `nombre` | Nombre brut (lits, places, CMP, équivalents temps plein ou patients selon l'indicateur). |
| `traitement` | Ce qui en a été fait. |

## robustesse_gini.csv

Indice de Gini avec intervalle de confiance, et selon l'échelle géographique.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `gini_epci` | Indice de Gini calculé à l'échelle indiquée. |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `gini_com` | Indice de Gini calculé à l'échelle indiquée. |
| `gini_dep` | Indice de Gini calculé à l'échelle indiquée. |
| `gini_reg` | Indice de Gini calculé à l'échelle indiquée. |

## sante_mentale_assurance_maladie_odbl.csv

Personnes prises en charge pour troubles psychiques ou sous psychotropes, par département et région (Assurance Maladie, cartographie des pathologies). Mesure le recours aux soins, pas le besoin. Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `indicateur` | Identifiant de l'indicateur (voir les indicateurs de contexte). |
| `top` | Code de la catégorie dans la cartographie des pathologies de l'Assurance Maladie. |
| `libelle_officiel` | Libellé officiel de l'affection dans la liste des ALD. |
| `patients` | Nombre de personnes prises en charge (tous âges, tous sexes). |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `prevalence_brute_pct` | Patients rapportés à la population couverte, en %. |
| `prevalence_standardisee_pct` | Prévalence standardisée sur la structure d'âge de la France (méthode directe), en %. Vide si le secret statistique masque trop de cases d'âge. |
| `couverture_ages` | Part des patients retrouvée dans les cases d'âge (contrôle du secret statistique). |

## sante_mentale_sante_publique_france.csv

Indicateurs de Santé publique France (portail Odissé), décès par suicide, gestes auto-infligés, Baromètre de Santé publique France, par département ou par région selon l'indicateur.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `indicateur` | Identifiant de l'indicateur (voir les indicateurs de contexte). |
| `annee` | Année des données (pour le fichier des diplômes, année d'obtention, non disponible dans l'extraction publique actuelle). |
| `valeur` | Valeur de l'indicateur, dans l'unité indiquée par le dictionnaire des indicateurs. |
| `ic_bas` | Borne de l'intervalle de confiance à 95 % (indicateurs d'enquête). |
| `ic_haut` | Borne de l'intervalle de confiance à 95 % (indicateurs d'enquête). |

## secteurs.csv

Effectifs par secteur d'activité déclaré au RPPS, France et départements.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `secteur_libelle_officiel` | Secteur d'activité, libellé officiel de la nomenclature RPPS. |
| `n` | Nombre de personnes distinctes. |
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `categorie` | Catégorie d'établissement, libellé d'affichage. |
| `secteur` | Code du secteur de psychiatrie quand le nom de la structure le cite (93G16, 31I01, G pour la psychiatrie générale, I pour la psychiatrie infanto-juvénile, Z pour un intersecteur), vide sinon. Il ne dit pas quelles communes le secteur dessert. |

## secteurs_conventionnels_odbl.csv

Libéraux par secteur conventionnel (secteur 1, secteur 2 avec ou sans Optam, non conventionnés), par spécialité, en France, par région et par département (Assurance Maladie). Partie issue de données sous licence ODbL (Assurance Maladie), diffusée sous la même licence (partage à l'identique).

| Colonne | Description |
|---|---|
| `profession_sante` | Spécialité, libellé de l'Assurance Maladie. |
| `secteur_1` | Libéraux conventionnés en secteur 1 (tarif de la Sécurité sociale). |
| `secteur_2_optam` | Libéraux en secteur 2 ayant adhéré à l'Optam (dépassements encadrés). |
| `secteur_2_sans_optam` | Libéraux en secteur 2 sans Optam. |
| `secteur_2` | Libéraux conventionnés en secteur 2 (dépassements possibles), avec ou sans Optam. |
| `non_conventionnes` | Libéraux non conventionnés. |
| `liberaux` | Total des libéraux, conventionnés ou non. |
| `part_depassements` | Part des libéraux pouvant pratiquer des dépassements d'honoraires (secteur 2 et non conventionnés), non calculée sous 5 libéraux. |
| `part_depassements_libres` | Part des libéraux en secteur 2 sans Optam ou non conventionnés. |
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `annee` | Année des données (pour le fichier des diplômes, année d'obtention, non disponible dans l'extraction publique actuelle). |

## secteurs_psychiatrie.csv

Sectorisation psychiatrique d'après les arrêtés des agences régionales de santé reçus (Hauts-de-France, arrêté du 26 décembre 2023), une ligne par commune, type de secteur et secteur, avec l'établissement responsable. Documents administratifs communiqués, réutilisables sans altération avec leur source et leur date (code des relations entre le public et l'administration, articles L321-1 et L322-1). Les autres régions n'y figurent pas, leur arrêté n'étant pas encore reçu.

| Colonne | Description |
|---|---|
| `reg` | Code de la région. |
| `dep` | Code du département. |
| `commune` | Code de la commune actuelle (code officiel géographique) rattachée au secteur. |
| `partie` | Partie de commune quand une ville est découpée entre plusieurs secteurs (« LILLE NORD »), vide sinon. |
| `type` | Type de secteur dans l'arrêté (G psychiatrie générale, I psychiatrie infanto-juvénile). |
| `type_secteur` | Type de secteur de psychiatrie, générale (adultes) ou infanto-juvénile. |
| `secteur_psychiatrie` | Code du secteur de psychiatrie dans l'arrêté de l'ARS (59G22, G pour la psychiatrie générale des adultes, I pour la psychiatrie infanto-juvénile). |
| `etablissement_responsable` | Établissement de santé responsable du secteur, tel que l'arrêté le nomme. |
| `finess_entite_juridique` | Numéro FINESS de l'entité juridique de l'établissement responsable. |
| `code_arrete` | Code de commune écrit dans l'arrêté, avant rattachement à la commune actuelle. |
| `nom_arrete` | Nom de commune écrit dans l'arrêté. |
| `rattachement` | Façon dont la commune actuelle a été retrouvée, par son code, par l'ancien code d'une commune fusionnée, ou par son nom quand le code a changé depuis l'arrêté. |
| `document` | Document source, arrêté de l'agence régionale de santé. |
| `date_document` | Date du document source. |

## sensibilite_accessibilite.csv

Sensibilité de l'accessibilité à deux étapes à la portée retenue, comparée au calcul de référence à 20 km.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `portee_km` | Portée de l'accessibilité à deux étapes, en kilomètres. |
| `rho_epci` | Corrélation de rang entre les deux indicateurs, calculée sur les intercommunalités. |
| `quart_bas_conserve` | Part des intercommunalités du quart le moins accessible à 20 km qui y restent avec cette portée. |

## sensibilite_confirmation.csv

Résultats clés sur les structures de soins recalculés avec les seules structures confirmées par une source indépendante de FINESS et du ROR (sources de l'établissement, autre source publique, certification de la HAS, Sirene), pour dire si la conclusion tient sans les structures non confirmées.

| Colonne | Description |
|---|---|
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `libelle_type` | Libellé du type de structure de soins. |
| `mesure` | Résultat recalculé (nombre, distance médiane, part à plus de 20 km, classement des départements, éloignement selon le niveau de vie). |
| `toutes` | Valeur avec toutes les structures recensées. |
| `confirmees` | Valeur avec les seules structures confirmées par une source indépendante de FINESS et du ROR. |
| `conclusion_identique` | Vrai quand la conclusion ne change pas (écart de moins d'un kilomètre ou de deux points, corrélation de rang d'au moins 0,9, même sens et même netteté du lien). |

## sensibilite_ile_de_france.csv

Corrélation de rang entre l'offre de santé mentale et les indicateurs de besoin, avec tous les départements et sans ceux d'Île-de-France, où les suicides sont nettement sous-déclarés.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `variable` | Indicateur de contexte ou variable du modèle. |
| `rho_tous` | Corrélation de rang avec tous les départements. |
| `n_<profession>` | Nombre de personnes distinctes de la profession <profession> qui déclarent exercer dans le territoire. |
| `rho_sans_ile_de_france` | Corrélation de rang sans les huit départements d'Île-de-France. |

## sirene_sans_correspondant.csv

Établissements actifs du répertoire Sirene, sous une enseigne de CMP ou d'une autre structure de santé mentale (CATTP, hôpital de jour, CMPP, CAMSP, CSAPA, CAARUD), sans structure correspondante dans FINESS ou le ROR, à vérifier.

| Colonne | Description |
|---|---|
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `ej` | Numéro FINESS de l'entité juridique (l'hôpital ou l'association gestionnaire). |
| `siret` | Numéro SIRET de l'établissement Sirene. |
| `enseigne` | Enseigne de l'établissement dans Sirene. |
| `adresse` | Adresse de la structure (voie), quand elle est connue. |
| `commune` | Commune de l'établissement. |
| `date_creation` | Date de création de l'établissement dans Sirene. |
| `nom_commune` | Nom de la commune. |

## spatial.csv

Indices de Moran (ressemblance entre territoires voisins).

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `moran_I` | Indice de Moran. |
| `p_permutation` | p-valeur par permutations. |

## structures_gardees_a_verifier.csv

Inscriptions de FINESS ou du ROR absentes de la liste vérifiée de leur établissement mais confirmées par la certification HAS ou Sirene, gardées en attendant une vérification à la main.

| Colonne | Description |
|---|---|
| `ej` | Numéro FINESS de l'entité juridique (l'hôpital ou l'association gestionnaire). |
| `etablissement` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `nom` | Nom du territoire. |
| `commune` | Commune de l'établissement. |
| `nom_commune` | Nom de la commune. |
| `finess` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `provenance` | FINESS et ROR, FINESS seul ou ROR seul. |
| `raison` | Raison pour laquelle l'inscription n'est pas retenue. |

## structures_non_retenues.csv

Inscriptions de FINESS ou du ROR qui ne correspondent à aucune structure de la liste vérifiée de leur établissement.

| Colonne | Description |
|---|---|
| `ej` | Numéro FINESS de l'entité juridique (l'hôpital ou l'association gestionnaire). |
| `etablissement` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `nom` | Nom du territoire. |
| `commune` | Commune de l'établissement. |
| `nom_commune` | Nom de la commune. |
| `finess` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `provenance` | FINESS et ROR, FINESS seul ou ROR seul. |
| `raison` | Raison pour laquelle l'inscription n'est pas retenue. |

## structures_principales.csv

Principales structures d'exercice salarié par profession, France et départements (raisons sociales d'établissements).

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `rs` | Raison sociale de l'établissement. |
| `commune` | Commune de l'établissement. |
| `n` | Nombre de personnes distinctes. |
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |

## substitution.csv

Corrélations entre densités de paires de professions, brutes et à densité de population égale.

| Colonne | Description |
|---|---|
| `prof_a` | Identifiant de chacune des deux professions comparées. |
| `prof_b` | Identifiant de chacune des deux professions comparées. |
| `rho` | Corrélation de rang de Spearman. |
| `ic95_bas` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `ic95_haut` | Bornes de l'intervalle de confiance à 95 % (bootstrap). |
| `rho_partiel_densite` | Corrélation partielle de rang à densité de population égale (effet ville retiré). |
| `ic95_bas_partiel` | Borne de l'intervalle de confiance à 95 % de la corrélation partielle. |
| `ic95_haut_partiel` | Borne de l'intervalle de confiance à 95 % de la corrélation partielle. |
| `territoires` | Nombre de territoires. |

## temps_acces.csv

Temps de trajet en voiture vers l'équipement ou le professionnel libéral le plus proche (INSEE), par France, région, département et intercommunalité.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `equipement` | Type d'équipement ou de professionnel libéral de la base permanente des équipements (INSEE). |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `libelle` | Libellé de la profession. |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `temps_moyen_min` | Temps de trajet moyen en voiture (minutes) vers l'équipement le plus proche, pondéré par la population, à tous les niveaux. |
| `part_population_a_plus_de_15_min` | Part des habitants à plus de 15 minutes de route de l'équipement le plus proche. |
| `part_population_a_plus_de_20_min` | Part des habitants à plus de 20 minutes de route de l'équipement le plus proche. |
| `part_population_a_plus_de_30_min` | Part des habitants à plus de 30 minutes de route de l'équipement le plus proche. |
| `part_population_non_calculee` | Part des habitants pour lesquels l'INSEE ne calcule pas de temps de trajet. |
| `temps_median_min` | Temps de trajet median en voiture (minutes) vers l'équipement le plus proche, pondéré par la population, à tous les niveaux. |
| `part_population_temps_contredit` | Psychiatrie ambulatoire seulement. Part des habitants qui vivent dans une commune où le temps de l'INSEE dépasse 30 minutes alors qu'un CMP est à moins de 8 km à vol d'oiseau. |
| `fiable` | Vrai quand le temps de trajet est montré. Faux pour la psychiatrie ambulatoire quand plus de 1 % des habitants vivent dans une commune où il contredit la distance au CMP, le temps n'est alors pas montré sur le site ni dans les rapports. |

## temps_acces_communes.csv

Temps de trajet médian en voiture des habitants de chaque commune jusqu'à la structure de psychiatrie ambulatoire (CMP) et au service d'urgences les plus proches, données des cartes des rapports départementaux (INSEE, distancier, Licence Ouverte).

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `nom` | Nom du territoire. |
| `equipement` | Type d'équipement ou de professionnel libéral de la base permanente des équipements (INSEE). |
| `temps_median_min` | Temps de trajet median en voiture (minutes) vers l'équipement le plus proche, pondéré par la population, à tous les niveaux. |

## temps_route_communes.csv

Temps de route en voiture des habitants de chaque commune vers la structure la plus proche de chaque type, à l'échelle du distancier de l'INSEE, et avec le moteur prudent de la Géoplateforme de l'IGN.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `habitants` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `temps_route_median_min` | Temps de route médian des habitants, en minutes, à l'échelle du distancier de l'INSEE (seuils des isochrones de la Géoplateforme de l'IGN calés sur la part des habitants que l'INSEE publie vers les urgences), interpolé dans sa tranche de temps. |
| `part_route_plus_15_min` | Part des habitants à plus de 15 minutes de route, à l'échelle du distancier de l'INSEE. |
| `part_route_plus_20_min` | Part des habitants à plus de 20 minutes de route, à l'échelle du distancier de l'INSEE. |
| `part_route_plus_30_min` | Part des habitants à plus de 30 minutes de route, à l'échelle du distancier de l'INSEE. |
| `part_route_plus_45_min` | Part des habitants à plus de 45 minutes de route, à l'échelle du distancier de l'INSEE. |
| `temps_route_median_min_prudent` | Temps de route médian des habitants, en minutes, avec le moteur de la Géoplateforme de l'IGN tel quel, plus prudent, borne haute de la fourchette. |
| `part_route_plus_15_min_prudent` | Part des habitants à plus de 15 minutes de route avec le moteur prudent de la Géoplateforme de l'IGN, borne haute de la fourchette. |
| `part_route_plus_20_min_prudent` | Part des habitants à plus de 20 minutes de route avec le moteur prudent de la Géoplateforme de l'IGN, borne haute de la fourchette. |
| `part_route_plus_30_min_prudent` | Part des habitants à plus de 30 minutes de route avec le moteur prudent de la Géoplateforme de l'IGN, borne haute de la fourchette. |
| `part_route_plus_45_min_prudent` | Part des habitants à plus de 45 minutes de route avec le moteur prudent de la Géoplateforme de l'IGN, borne haute de la fourchette. |

## temps_route_territoires.csv

Temps de route en voiture des habitants vers la structure la plus proche de chaque type, par intercommunalité, département, région et pour la France, aux deux échelles.

| Colonne | Description |
|---|---|
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `habitants` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `temps_route_median_min` | Temps de route médian des habitants, en minutes, à l'échelle du distancier de l'INSEE (seuils des isochrones de la Géoplateforme de l'IGN calés sur la part des habitants que l'INSEE publie vers les urgences), interpolé dans sa tranche de temps. |
| `part_route_plus_15_min` | Part des habitants à plus de 15 minutes de route, à l'échelle du distancier de l'INSEE. |
| `part_route_plus_20_min` | Part des habitants à plus de 20 minutes de route, à l'échelle du distancier de l'INSEE. |
| `part_route_plus_30_min` | Part des habitants à plus de 30 minutes de route, à l'échelle du distancier de l'INSEE. |
| `part_route_plus_45_min` | Part des habitants à plus de 45 minutes de route, à l'échelle du distancier de l'INSEE. |
| `temps_route_median_min_prudent` | Temps de route médian des habitants, en minutes, avec le moteur de la Géoplateforme de l'IGN tel quel, plus prudent, borne haute de la fourchette. |
| `part_route_plus_15_min_prudent` | Part des habitants à plus de 15 minutes de route avec le moteur prudent de la Géoplateforme de l'IGN, borne haute de la fourchette. |
| `part_route_plus_20_min_prudent` | Part des habitants à plus de 20 minutes de route avec le moteur prudent de la Géoplateforme de l'IGN, borne haute de la fourchette. |
| `part_route_plus_30_min_prudent` | Part des habitants à plus de 30 minutes de route avec le moteur prudent de la Géoplateforme de l'IGN, borne haute de la fourchette. |
| `part_route_plus_45_min_prudent` | Part des habitants à plus de 45 minutes de route avec le moteur prudent de la Géoplateforme de l'IGN, borne haute de la fourchette. |
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |

## tests_classes_densite.csv

Tests de différence entre classes de densité de population.

| Colonne | Description |
|---|---|
| `niveau` | Niveau géographique (FR, com, epci, dep, reg). |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `kruskal_H` | Statistique du test de Kruskal-Wallis. |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `epsilon2` | Taille d'effet epsilon² du test de Kruskal-Wallis. |
| `biserial_extremes` | Corrélation bisériale de rang entre classes extrêmes. |
| `p_mann_whitney_extremes` | p-valeur du test de Mann-Whitney entre classes extrêmes. |
| `q_bh` | q-valeur après correction de Benjamini-Hochberg. |

## typologie_affectation.csv

Groupe de chaque intercommunalité dans les trois typologies (santé mentale, santé, ensemble) et sa position sur les deux premiers axes de l'analyse en composantes principales.

| Colonne | Description |
|---|---|
| `famille` | Famille, « Santé mentale » ou « Santé » (dans les fichiers de la typologie, sm, sante ou tout). |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `classe` | Classe de densité de population ou groupe de la typologie. |
| `axe1` | Coordonnée de l'intercommunalité sur l'axe 1 de l'analyse en composantes principales. |
| `axe2` | Coordonnée de l'intercommunalité sur l'axe 2 de l'analyse en composantes principales. |

## typologie_lieux.csv

Structures de soins et distances décrites dans chaque groupe de la typologie, à titre descriptif (ils ne servent pas à former les groupes).

| Colonne | Description |
|---|---|
| `famille` | Famille, « Santé mentale » ou « Santé » (dans les fichiers de la typologie, sm, sante ou tout). |
| `classe` | Classe de densité de population ou groupe de la typologie. |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `lieux_pour_100000` | Nombre de structures de soins de ce type pour 100 000 habitants. |
| `indice_vs_national` | Indice de densité, 100 pour l'ensemble des intercommunalités. |
| `distance_mediane_km` | Distance médiane des habitants à la structure la plus proche, en km, à vol d'oiseau, cherchée sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucune. |

## typologie_profils.csv

Profil de chaque groupe de la typologie (indice 100 = France).

| Colonne | Description |
|---|---|
| `famille` | Famille, « Santé mentale » ou « Santé » (dans les fichiers de la typologie, sm, sante ou tout). |
| `classe` | Classe de densité de population ou groupe de la typologie. |
| `prof` | Identifiant de la profession (voir professions.csv). |
| `indice_vs_national` | Indice de densité, 100 pour l'ensemble des intercommunalités. |
| `territoires` | Nombre de territoires. |
| `population` | Population du territoire (référentiel Etalab, population municipale). |
| `dans_typologie` | Description manquante, à compléter dans pipeline/dictionnaire.py. |

## typologie_qualite.csv

Qualité de chaque typologie, nombre de groupes, silhouette et part des différences entre intercommunalités résumée par les groupes et les axes.

| Colonne | Description |
|---|---|
| `famille` | Famille, « Santé mentale » ou « Santé » (dans les fichiers de la typologie, sm, sante ou tout). |
| `classes` | Nombre de groupes retenu. |
| `silhouette` | Silhouette moyenne de la partition, de -1 à 1, sous 0,25 les groupes sont peu séparés. |
| `part_inertie_classes` | Part des différences entre intercommunalités expliquée par les groupes. |
| `part_inertie_axes_1_2` | Part des différences résumée par les deux premiers axes. |
| `variables` | Nombre de professions utilisées. |
| `stabilite_min` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `stabilite_max` | Description manquante, à compléter dans pipeline/dictionnaire.py. |

## variance_niveaux.csv

Part de la variation de densité entre intercommunalités due aux départements.

| Colonne | Description |
|---|---|
| `prof` | Identifiant de la profession (voir professions.csv). |
| `part_entre_departements` | Part de la variation du logarithme de la densité expliquée par le département. |

## verdicts_sans_structure.csv

Verdicts de la vérification à la main qui ne retrouvent plus leur structure (clé changée par une mise à jour des bases ou structure déjà réunie à une autre), à revoir.

| Colonne | Description |
|---|---|
| `cle` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `structure` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `verdict` | Résultat de la vérification à la main d'une structure inscrite seulement dans les bases ou absente de la liste de son établissement (existe, ou pas_un_cmp pour une unité rangée dans son type réel). Vide sans vérification à la main. |
| `finess` | Description manquante, à compléter dans pipeline/dictionnaire.py. |
| `situation` | Ce qu'est devenue l'inscription d'un verdict sans structure, d'après le numéro FINESS de sa clé (numéro fermé dans FINESS, renommée sous le même numéro, même nom mais autre commune ou autre gestionnaire, disparue des bases). |
| `structure_actuelle` | Nom de la structure qui porte aujourd'hui le même numéro FINESS, quand l'inscription a été renommée. Le verdict ne lui est pas reporté. |

## zones_eloignement.csv

Zones où l'éloignement des habitants à une structure de soins se concentre, Moran local des distances médianes par intercommunalité, avec correction de Benjamini-Hochberg.

| Colonne | Description |
|---|---|
| `type_structure` | Type de structure dont la distance est étudiée. |
| `code` | Code officiel du territoire (COG pour communes et départements, SIREN pour les EPCI). Un code commençant par C désigne une commune qui n'appartient à aucune intercommunalité. |
| `I` | Indice de Moran local du territoire. |
| `z` | Statistique de test. |
| `p` | p-valeur (indicative, les données sont un recensement). |
| `type` | Première lettre, valeur du territoire haute (H) ou basse (L), seconde lettre, valeur de ses voisins. Dans lisa.csv, la même densité. Dans offre_besoin_lisa.csv, l'indicateur du département puis l'offre des voisins. |
| `q_bh` | q-valeur après correction de Benjamini-Hochberg. |
| `zone` | Zone d'éloignement groupé (intercommunalité éloignée entourée d'intercommunalités éloignées), de proximité groupée, intercommunalité éloignée ou proche isolée, ou non significatif après correction. |
| `distance_mediane_km` | Distance médiane des habitants à la structure la plus proche, en km, à vol d'oiseau, cherchée sur le même territoire (Hexagone, Corse ou département d'outre-mer), vide quand ce territoire n'en compte aucune. |
| `moran_global` | Indice de Moran global des distances et sa p-valeur par permutations. |
| `p_moran_global` | Indice de Moran global des distances et sa p-valeur par permutations. |
| `libelle_type` | Libellé du type de structure de soins. |
| `nom` | Nom du territoire. |
